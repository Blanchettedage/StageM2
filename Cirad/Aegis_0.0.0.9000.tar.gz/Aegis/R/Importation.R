

#' Fonction importation
#'
#'Cette fonction a pour but de récupérer les feuilles de tous les fichiers Excel.
#'A travers la fonction 'list.files()', il récupère les fichiers contenu dans
#'le chemin qui sera mentionné et met dans une liste. Ensuiste, il récupère le
#'nom des feuilles de chaque fichier avec la fonction 'excel_sheets()'.Enfin,
#'pour chaque feuille de fichier, assigne les données aux entetes et range
#'  dans l'environnement Global.
#'
#' @param chemin une chaine de caratère, qui récupère le chemin du dossier dans lequel se trouve nos fichiers excels
#'
#' @return Fonction :Cette fonction nous retourne la liste des feuilles contenues dans chaque fichier excel.
#' @export
#'
#' @examples
#' \dontrun{
#' # ----- Importation des données depuis un emplacement de votre machine
#'
#' # créer une variable vide qui va récuperer la liste des fichiers
#' Aegis<-NULL
#'import_Aegis("C:/chemin/vers/le/dossier/des/fichiers/Excel")
#'
#'
#'}

import_Aegis<-function(chemin){

  files<- list.files(chemin, pattern = "*.xlsx", full.names = TRUE)
  files
  #compte le nombre de fichiers présents dans le document
  nb_files <- length(files)
  nb_files

  #creation d'un vecteur vide pour récupérer les entetes
  data_names <- vector("list",length=nb_files)

  #pour récupérer les entetes des feuilles
  for (i in 1 : nb_files){
    #data_names[i] <- strsplit(files[i], split=".csv")
    data_names [[i]]<- readxl::excel_sheets(files[i])

  }

  # creation d'une liste vide pour recuperer les fichiers
  data<-list()
  # importe les données et les associer aux feuilles
  for (i in 1:nb_files) { #pour les fichiers
    for (j in 1:length(data_names[[i]])){ # pour chaque feuilles de  fichiers
      data[[paste0(data_names[[i]][j])]]<-readxl::read_excel( files[i], sheet= data_names[[i]][j])
    }
  }
  Aegis<<-data
}
