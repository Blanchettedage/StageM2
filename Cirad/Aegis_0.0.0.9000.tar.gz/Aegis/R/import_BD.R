
#' Importer des colonnes
#'
#' Cette fonction nous permettra d'appeler la connexion et récupérer certains champs dans des tables de la base de données.
#'
#' @param con  appelle la connexion qui permet d'accéder à la base de données
#' @param table_db récupère le nom de la table pour laquelle nous voulons des informations
#' @param champs récupère le nom des champs que nous voulons utiliser.
#'
#' @return fonction: Cette fonction, retourne les données des différentes colonnes pris depuis la base de données
#' @export
#'
#' @examples
#'
#'
#'# -----Importation des données depuis la base de données
#'
#'
#'User='postgres'
#'mot_passe='dage'
#'host_db='localhost'
#'port_db=5432
#'dbname='daphne_dev'
#'con <- DBI::dbConnect(RPostgres::Postgres(), user=User, password=mot_passe,
#'                      host=host_db, port=5432, dbnam = dbname)
#'
#' # taxo
#' taxo_database<-import_data(con, "public.taxo", c("taxo_id", "taxo_code"))
#'
#' #wday
#' ws_database<-import_data(con, "public.ws", c("wscode", "wsname"))
#'
#'
#'

import_data<- function(con, table_db, champs){
  query<- paste("SELECT", paste(champs,collapse=","), "FROM", table_db
                )
  result<-DBI::dbGetQuery(con, query )

  #print(result)
}


