#' Suppression des données
#'
#' Cette fonction part d'une table passée en paramètre, la parcourt et vérifie si
#' chaque ligne existe déjà dans la base de données. Si oui elle vous demandera
#' si oui/non vous voulez là supprimer. En cas de validation, la fonction
#' supprimera toutes les données relatives au code de cette ligne.
#'
#' @param con : Appelle la connexion qui permet d'accéder à la base de données
#' @param Aegis_Trial: prend la table contenant les données à valider et supprimer
#'
#' @return supprime simplement toutes les données de la base de données
#' @export
#'
#' @examples
#' \dontrun{
#'  #-- importation des données depuis un emplacement de votre machine
#' Aegis<-NULL
#' import_Aegis("C:/chemin/vers/le/dossier/des/fichiers/Excel")
#' print(Aegis)
#'
#' #-- Connexion à la base de données.Remplacez les informations connexion
#'
#' User='postgres'
#' mot_passe='dage'
#' host_db='localhost'
#' port_db=5432
#' dbname='daphne_dev'
#'
#' con <- DBI::dbConnect(RPostgres::Postgres(), user=User, password=mot_passe,
#' host=host_db, port=5432, dbname=dbname)
#'
#'suppression(con,Aegis$Trial )
#'
#' }

# Charger le package DBI pour utiliser les fonctions de connexion à la base de données
library(DBI)

suppression <- function(con, Aegis_Trial) {
  for(i in seq_len(nrow(Aegis_Trial))) {
    # Vérifier si la valeur numéro i du champ factor existe déjà dans la bd
    existe <- dbGetQuery(con, paste0("SELECT * FROM trial WHERE trial_code ='", Aegis_Trial$trial_code[i], "'"))

    if(nrow(existe) > 0) {
      message("La valeur '", Aegis_Trial$trial_code[i], "' existe déjà dans la base de données.\n")

      reponse <- readline("Voulez-vous la supprimer ? (oui/non): ")
      if(reponse == "oui") {
        query <- paste0("DELETE FROM trial WHERE trial_code ='", Aegis_Trial$trial_code[i], "'")
        dbClearResult(existe)  # Fermer le jeu de résultats précédent
        resultat <- dbSendQuery(con, query)

        message("La valeur '", Aegis_Trial$trial_code[i], "' est supprimée de la base de données")

      } else if(reponse == "non") {
        message("Veuillez rentrer un autre Trial Code pour la vérification ")
      }

    } else {
      # Si cette valeur là n'existe pas, l'ajouter à la suite
      message("La valeur '", Aegis_Trial$trial_code[i], "' n'existe pas dans la base de données. Vous pouvez utiliser la fonction sauvegarde pour la sauvegarder.")
    }
  }
}
