
#' Traitement & Sauvegarde
#'
#'Cette Fonction va parcourir les fichiers contenus dans Aegis,
#'tester s'ils correspondent à certaines tables de la base de données.
#'Par la suite cette fonction va, effectuer les traitements appropriés à
#'chaque fichier  et les sauvegarder dans la base de données.
#'
#' @param con : Appelle la connexion qui permet d'accéder à la base de données
#' @param Aegis : Contient la liste des fichiers à traiter et sauvegarder
#'
#' @return Cette fonction sauvegarde les données directement dans la base de données
#' @export
#'
#' @examples
#'\dontrun{
#'
#' #-- importation des données depuis un emplacement de votre machine
#' Aegis<-NULL
#' import_Aegis("C:/chemin/vers/le/dossier/des/fichiers/Excel")
#' print(Aegis)
#'
#' #-- Connexion à la base de données.remplacez les informations connexion
#'
#' User='postgres'
#' mot_passe='dage'
#' host_db='localhost'
#' port_db=5432
#' dbname='daphne_dev'
#'
#' con <- DBI::dbConnect(RPostgres::Postgres(), user=User, password=mot_passe,
#' host=host_db, port=5432, dbnam = dbname)
#'
#' # Traitement et sauvegarde
#'
#'sauvegarde(con,Aegis)
#'
#' # Deconnexion de la base de données
#' dbDisconnect(con)
#' }

sauvegarde<- function(con, Aegis){


  #------------------------------ Scale ---------------------------------------#
  #   if (fich == "Scale"){

  itable <- which(names(Aegis)=="Scale")

  scale <- Aegis[[itable]]

  #Sauvegarde
  for(i in seq_len(nrow(scale))){

    #vérifier si la valeur numero i du champs factor existe déja dans la bd
    existe<-dbGetQuery(con, paste0("SELECT * FROM scale WHERE scale_code='",
                                   scale$scale_code[i], "'"))

    if(nrow(existe)>0){
      message("la valeur ",scale$scale_code[i]," de la table scale existe déjà dans la table")
    }
    # si cette valeur là n'existe pas,l'ajouter à la suite
    if (nrow(existe)==0){
      # trait_sauve(con, "scale", scale[i,])
      DBI::dbWriteTable( con, "scale", scale[i,], append = TRUE, overwrite = FALSE )
    }
  }




  #----------------------Method ------------------------------------------ ######
  #    }else if (fich == "Method"){

  itable <- which(names(Aegis)=="Method")
  method<-Aegis[[itable]]

  #Sauvegarde
  for(i in seq_len(nrow(method))){

    #vérifier si la valeur numero i du champs factor existe déja dans la bd
    existe<-dbGetQuery(con, paste0("SELECT * FROM method WHERE method_code='",
                                   method$method_code[i], "'"))

    if(nrow(existe)>0){
      message("la valeur ",method$method_code[i]," Existe déjà dans la table")
    }
    # si cette valeur là n'existe pas,l'ajouter à la suite
    if (nrow(existe)==0){
      # trait_sauve(con, "method", method[i,])
      DBI::dbWriteTable( con, "method", method[i,], append = TRUE, overwrite = FALSE)
    }
  }


  # --------------------------------Entity--------------------------------------##
  #    }else if (fich =="Entity"){

  itable <- which(names(Aegis)=="Entity")
  entity<-Aegis[[itable]]

  #Sauvegarde
  for(i in seq_len(nrow(entity))){

    #vérifier si la valeur numero i du champs factor existe déja dans la bd
    existe<-dbGetQuery(con, paste0("SELECT * FROM entity WHERE entity_code='",
                                   entity$entity_code[i], "'"))

    if(nrow(existe)>0){
      message("la valeur ",entity$entity_code[i]," de la table Entity existe déjà dans la table")
    }
    # si cette valeur là n'existe pas,l'ajouter à la suite
    if (nrow(existe)==0){
      # trait_sauve(con, "entity", entity[i,])
      DBI::dbWriteTable( con, "entity", entity[i,], append = TRUE, overwrite = FALSE)
    }
  }

  #---------------------Target----------------------------------------------#####
  #    }else if (fich == "Target"){

  itable <- which(names(Aegis)=="Target")
  target<-Aegis[[itable]]

  #Sauvegarde
  for(i in seq_len(nrow(target))){

    #vérifier si la valeur numero i du champs factor existe déja dans la bd
    existe<-dbGetQuery(con, paste0("SELECT * FROM target WHERE target_name='",
                                   target$target_name[i], "'"))

    if(nrow(existe)>0){
      message("la valeur ",target$target_name[i]," de la table Target existe déjà dans la table")
    }
    # si cette valeur là n'existe pas,l'ajouter à la suite
    if (nrow(existe)==0){
      # trait_sauve(con, "target", target[i,])
      DBI::dbWriteTable( con, "target", target[i,], append = TRUE, overwrite = FALSE)
    }
  }
  #--------------------------------Trait--------------------------------------####
  #    }else if(fich == "Trait"){

  itable <- which(names(Aegis)=="Trait")
  Trait<-Aegis[[itable]]

  # renommer une colonne trait_entity_code
  Trait<-Aegis$Trait %>%rename(trait_entity = trait_entity_code)

  # renommer une colonne trait_target
  trait<-Trait %>%rename(trait_target = trait_target_name)


  #Sauvegarde
  for(i in seq_len(nrow(trait))){

    #vérifier si la valeur numero i du champs factor existe déja dans la bd
    existe<-dbGetQuery(con, paste0("SELECT * FROM trait WHERE trait_code='",
                                   trait$trait_code[i], "'"))

    if(nrow(existe)>0){
      message("la valeur ",trait$trait_code[i]," de la table trait existe déjà dans la table")
    }
    # si cette valeur là n'existe pas,l'ajouter à la suite
    if (nrow(existe)==0){
      #trait_sauve(con, "trait", trait[i,])
      DBI::dbWriteTable( con, "trait", trait[i,], append = TRUE, overwrite = FALSE)
    }
  }


  #----------------------------------Variable-------------------------------#####

  #    }else if(fich =="Variable"){

  itable <- which(names(Aegis)=="Variable")
  Variable<- Aegis[[itable]]


  #Sauvegarde
  for(i in seq_len(nrow(Variable))){

    #vérifier si la valeur numero i du champs factor existe déja dans la bd
    existe<-dbGetQuery(con, paste0("SELECT * FROM variable WHERE variable_code='",
                                   Variable$variable_code[i], "'"))

    if(nrow(existe)>0){
      message("la valeur ",Variable$variable_code[i]," de la table variable existe déjà dans la table")
    }
    # si cette valeur là n'existe pas,l'ajouter à la suite
    if (nrow(existe)==0){
      #trait_sauve(con, "Variable", Variable[i,])
      DBI::dbWriteTable( con, "variable", Variable[i,], append = TRUE, overwrite = FALSE)
    }
  }

  #---------------------------------  Factor ----------------------------------###

  #    } else if (fich == "Factor"){

  itable <- which(names(Aegis)=="Factor")
  Factor<- Aegis[[itable]]

  factor_code_max<-as.numeric(max(import_database(con,"public.factor" , c("factor_id"))$factor_id))
  if(factor_code_max < -1000){factor_code_max=1}
  #  Factor$factor_id <- factor_code_max+(1:nrow(Factor))
  Factor$factor_id <- NA
  ID <- factor_code_max

  for(i in seq_len(nrow(Factor))){
    #
    #   #vérifier si la valeur numero i du champs factor existe déja dans la bd
    existe<-dbGetQuery(con, paste0("SELECT * FROM factor WHERE
           factor='", Factor$factor[i], "'"))
    #
    if(nrow(existe)>0){
      message("la valeur ",Factor$factor[i]," de la table factor existe déjà dans la table")
    }
    #
    #   # si cette valeur la n'existe pas,l'ajouter à la suite
    if (nrow(existe)==0){
      #           trait_sauve(con, "factor", Factor[i,])
      Factor$factor_id <- ID
      ID <- ID+1
      DBI::dbWriteTable( con, "factor", Factor[i,], append = TRUE, overwrite = FALSE)
      #
    }

  }


  #---------------------- Factor_Level ------------------------###
  #    }else if (fich == "Factor_Level"){

  itable <- which(names(Aegis)=="Factor_Level")
  factor_level<-Aegis[[itable]]

  #factor_database : récupère les données depuis la database
  factor_database<- import_database(con, "public.factor", c("factor_id", "factor"))

  factor_level0<- merge(factor_database, factor_level, by="factor")


  # supprimer la colonne factor
  Factor_Level<- select(factor_level0, -factor)

  for(i in seq_len(nrow(Factor_Level))){

    #vérifier si la valeur numero i du champs factor existe déja dans la bd
    existe<-dbGetQuery(con, paste0("SELECT * FROM factor_level
                          WHERE factor_level='", Factor_Level$factor_level[i], "'"))

    if(nrow(existe)>0){
      message("la valeur ",Factor_Level$factor_level[i]," de la table factor_level existe déjà dans la table")
    }

    # si cette valeur là n'existe pas,l'ajouter à la suite
    if (nrow(existe)==0){
      #trait_sauve(con, "factor_level", Factor_Level[i,])
      DBI::dbWriteTable( con, "factor_level", Factor_Level[i,], append = TRUE, overwrite = FALSE)
    }
  }

  ###------------------------------Taxo ------------------------###
  #    }else if(fich == "Taxo"){
  itable <- which(names(Aegis)=="Taxo")
  taxo<-Aegis[[itable]]

  #Sauvegarde

  for(i in seq_len(nrow(taxo))){

    #vérifier si la valeur numero i du champs factor existe déja dans la bd
    existe<-dbGetQuery(con, paste0("SELECT * FROM taxo
                          WHERE taxo_code='", taxo$taxo_code[i], "'"))

    if(nrow(existe)>0){
      message("La valeur ",taxo$taxo_code[i]," de la table taxo existe déjà dans la table")
    }

    # si cette valeur là n'existe pas,l'ajouter à la suite
    if (nrow(existe)==0){
      #trait_sauve(con, "taxo", taxo[i,])
      DBI::dbWriteTable( con, "taxo", taxo[i,], append = TRUE, overwrite = FALSE)
    }
  }
  #--------------------------- Accession ------------------------###

  #    }else if(fich == "Accession"){

  itable <- which(names(Aegis)=="Accession")
  accession<-Aegis[[itable]]

  # importation des données depuis la base de données
  taxo_database<-import_database(con, "public.taxo", c("taxo_id", "taxo_code"))

  # jointure sur les deux tables
  jointure3<- merge(accession, taxo_database, by='taxo_code' )

  # suppression de la colonne inutile
  Accession<- dplyr::select(jointure3, -taxo_code)

  # Enregistrer dans la base de données
  for(i in seq_len(nrow(Accession))){

    #vérifier si la valeur numero i du champs factor existe déja dans la bd
    existe<-dbGetQuery(con, paste0("SELECT * FROM accession WHERE accession_code='",
                                   Accession$accession_code[i], "'"))
    if(nrow(existe)>0){
      message("la valeur ",Accession$accession_code[i]," de la table Accession existe déjà dans la bd")
    }

    if (nrow(existe)==0){
      #trait_sauve(con, "accession", Accession[i,])
      DBI::dbWriteTable( con, "accession", Accession[i,], append = TRUE, overwrite = FALSE)
    }
  }

  #------------------------------  LOT  ----------------------###

  #    }else if( fich == "Seedlot"){

  itable <- which(names(Aegis)=="Seedlot")
  lot<-Aegis[[itable]]

  #renommer une colonne
  lot<- lot %>%rename(lot_code_partner =lot_partner_code)

  #récupérer l'id depuis la base de données
  accession_database<-import_database(con,"public.accession" , c("accession_id", "accession_code"))

  # jointure
  jointure4<- merge(lot, accession_database, by = 'accession_code')

  # suppression de la colonne inutile
  lot<- dplyr::select(jointure4, -accession_code)

  # sauvegarde
  for(i in seq_len(nrow(lot))){

    #vérifier si la valeur numero i du champs factor existe déja dans la bd
    existe<-dbGetQuery(con, paste0("SELECT * FROM lot WHERE lot_code='",
                                   lot$lot_code[i], "'"))

    if(nrow(existe)>0){
      message("la valeur ",lot$lot_code[i]," de la table lot existe déjà dans la table")
    }
    # si cette valeur là n'existe pas,l'ajouter à la suite
    if (nrow(existe)==0){
      #trait_sauve(con, "lot", lot[i,])
      DBI::dbWriteTable( con, "lot", lot[i,], append = TRUE, overwrite = FALSE)
    }
  }


  #------------------------------  WS -----------------------------------------###

  #   }else  if (fich == "Weather_station" ){

  itable <- which(names(Aegis)=="Weather_station")
  ws<-Aegis[[itable]]

  ws<- ws%>%rename(wsname = weather_station_name)
  ws<- ws%>%rename(wslat = latitude)
  ws<- ws%>%rename(wslong = longitude)
  ws<- ws%>%rename(wsalt = altitude)
  ws<- ws%>%rename(wstype = type)

  ws_code_max<-as.numeric(max(import_database(con,"public.ws" , c("wscode"))$wscode))
  if(ws_code_max < -1000){ws_code_max=1}
  #    ws$wscode <- ws_code_max+(1:nrow(ws))
  ws$wscode <- NA
  ID <- ws_code_max

  # sauvegarde vers la base de données
  for(i in seq_len(nrow(ws))){
    #
    #   #vérifier si la valeur numero i du champs factor existe déja dans la bd
    existe<-dbGetQuery(con, paste0("SELECT * FROM ws WHERE wsname='",
                                   ws$wsname[i], "'"))
    if(nrow(existe)>0){
      message("la valeur ",ws$wsname[i]," de la table w station existe déjà dans la table")
    }
    # si cette valeur là n'existe pas,l'ajouter à la suite
    if (nrow(existe)==0){
      #         trait_sauve(con, "ws", ws[i,])
      ws$wscode <- ID
      ID <- ID+1
      DBI::dbWriteTable( con, "ws", ws[i,], append = TRUE, overwrite = FALSE)
    }
  }

  #--------------------------------SOIL TYPE ----------------------------###
  itable <- which(names(Aegis)=="Trial")
  trial<-Aegis[[itable]]
  Soil_type <- unique(trial[,c('soil_code','soil_description')])

  Soil_type<- Soil_type%>%rename(symbol_soil_type = soil_code)
  Soil_type<- Soil_type%>%rename(soil_type = soil_description)

  # sauvegarde vers la base de données
  for(i in seq_len(nrow(Soil_type))){
    #
    #   #vérifier si la valeur numero i du champs factor existe déja dans la bd
    existe<-dbGetQuery(con, paste0("SELECT * FROM soil_type WHERE symbol_soil_type='",
                                   Soil_type$symbol_soil_type[i], "'"))
    if(nrow(existe)>0){
      message("la valeur ",Soil_type$symbol_soil_type[i]," de la table soil_type existe déjà dans la table")
    }
    # si cette valeur là n'existe pas,l'ajouter à la suite
    if (nrow(existe)==0){
      #         trait_sauve(con, "ws", ws[i,])
      DBI::dbWriteTable( con, "soil_type", Soil_type[i,], append = TRUE, overwrite = FALSE)
    }
  }

  #--------------------------------COUNTRY ----------------------------###
  itable <- which(names(Aegis)=='Site')
  Country<-Aegis[[itable]]

  Country <- unique(Country[,c('country_code','country_description')])

  Country<- Country%>%rename(country = country_description)

  # sauvegarde vers la base de données
  for(i in seq_len(nrow(Country))){
    #
    #   #vérifier si la valeur numero i du champs factor existe déja dans la bd
    existe<-dbGetQuery(con, paste0("SELECT * FROM country WHERE country_code='",
                                   Country$country_code[i], "'"))
    if(nrow(existe)>0){
      message("la valeur ",Country$country_code[i]," de la table country existe déjà dans la table")
    }
    # si cette valeur là n'existe pas,l'ajouter à la suite
    if (nrow(existe)==0){
      #         trait_sauve(con, "ws", ws[i,])
      DBI::dbWriteTable( con, "country", Country[i,], append = TRUE, overwrite = FALSE)
    }
  }

  #--------------------------------SITE ----------------------------###
  itable <- which(names(Aegis)=="Site")
  Site<-Aegis[[itable]]

  Site<- dplyr::select(Site, -country_description)
  Site<- Site%>%rename(country = country_code)

  # sauvegarde vers la base de données

  for(i in seq_len(nrow(Site))){

    #vérifier si la valeur numero i du champs factor existe déja dans la bd
    existe<-dbGetQuery(con, paste0("SELECT * FROM site WHERE site_code='",
                                   Site$site_code[i], "'"))
    if(nrow(existe)>0){
      message("la valeur ",Site$site_code[i]," de la table Site station existe déjà dans la table")
    }
    # si cette valeur là n'existe pas,l'ajouter à la suite
    if (nrow(existe)==0){
      #trait_sauve(con, "trial", trial[i,])
      DBI::dbWriteTable(con, "site", Site[i,], append = TRUE, overwrite = FALSE)
    }
  }

  #--------------------------------TRIAL ----------------------------###
  #    }else if (fich == "Trial"){

  itable <- which(names(Aegis)=="Trial")
  trial<-Aegis[[itable]]

  trial<- dplyr::select(trial, -soil_description)
  trial<- trial%>%rename(soil_type = soil_code)

  # sauvegarde vers la base de données

  for(i in seq_len(nrow(trial))){

    #vérifier si la valeur numero i du champs factor existe déja dans la bd
    existe<-dbGetQuery(con, paste0("SELECT * FROM trial WHERE trial_code='",
                                   trial$trial_code[i], "'"))
    if(nrow(existe)>0){
      message("la valeur ",trial$trial_code[i]," de la table trial station existe déjà dans la table")
    }
    # si cette valeur là n'existe pas,l'ajouter à la suite
    if (nrow(existe)==0){
      #trait_sauve(con, "trial", trial[i,])
      DBI::dbWriteTable(con, "trial", trial[i,], append = TRUE, overwrite = FALSE)
    }
  }


  #---------------------------- EXP UNIT --------------------------------###

  itable <- which(names(Aegis)=="Design")
  exp_unit<-Aegis[[itable]]
  #    exp_unit$unit_depth <- NA

  Trial_code_ID <- trial$trial_code
  existe<-dbGetQuery(con, paste0("SELECT * FROM exp_unit"))
  existe <- existe[which(existe$trial_code==Trial_code_ID),]
  lignes_communes<- intersect( exp_unit[c('unit_code','trial_code')], existe[,c('unit_code','trial_code')])

  #    exp_unit$surface <- as.numeric(exp_unit$surface)
  #    exp_unit_new <- setdiff(exp_unit[c('unit_code','trial_code')],existe[,c('unit_code','trial_code')])

  if((nrow(lignes_communes) == nrow(existe))&(nrow(existe>0))){'All exp_unit already presented in the database - not included'}

  if((nrow(lignes_communes) != nrow(existe))|(nrow(existe)==0)){
    #  requête SQL DELETE  pour supprimer les lignes correspondantes
    requet_sup <- paste0("DELETE FROM exp_unit WHERE ", "trial_code", "='", Trial_code_ID,"'")
    # Supprimer les lignes correspondantes de la base de données
    db_remove <- dbExecute(con, requet_sup )

    unit_code_max<-as.numeric(max(import_database(con,"public.exp_unit" , c("exp_unit_id"))$exp_unit_id))
    if(unit_code_max < -1000){unit_code_max=1}

    exp_unit$exp_unit_id <- unit_code_max+(1:nrow(exp_unit))

    exp_unit_temp <- exp_unit[,c('unit_code','exp_unit_id')]
    names(exp_unit_temp)[1] <- 'assigned_to'
    names(exp_unit_temp)[2] <- 'assigned_to_id'

    exp_unit <- merge(exp_unit,exp_unit_temp, by='assigned_to')
    exp_unit<- dplyr::select(exp_unit, -assigned_to)

    # renommer les colonnes
    exp_unit<-exp_unit %>%rename(x_coord=xcoord, y_coord= ycoord, assigned_to = assigned_to_id)

    # sauvegarde vers la base de données
    #trait_sauve(con, "exp_unit", exp_unit)
    DBI::dbWriteTable( con, "exp_unit", exp_unit, append = TRUE, overwrite = FALSE)
  }


  #--------------------------- OBS_Unit----------------------------------#

  itable <- which(names(Aegis)=="PlotPlant_data")
  obs_unit<-Aegis[[itable]]
  # renommer des colonnes
  obs_unit<-obs_unit%>%rename(obs_value=value_quantitative)

  # changer le format date
  obs_unit$obs_date= as.Date(obs_unit$obs_date, format='%d/%m/%Y')


  # importer de la base de données le exp_unit_id
  exp_unit_database<- import_database(con, "public.exp_unit" ,
                                      c("unit_code", "exp_unit_id", "trial_code" ))

  # on ne garde que les exp_unit correspondant
  trial_list <- unique(Aegis$Trial$trial_code)
  exp_unit_trial <- exp_unit_database %>% filter(trial_code %in% trial_list)


  # jointure pour récuperer l'id de exp_unit
  obs_unit<-merge(obs_unit,exp_unit_trial, by="unit_code")

  # supression des colonnes inutiles
  obs_unit<-dplyr::select(obs_unit, -trial_code, -unit_code)

  # renommer des champs
  obs_unit<- obs_unit %>%rename(unit_id= exp_unit_id)

  # test pour ne garder que les observations non présente dans la base
  obs_unit$obs_value <- as.numeric(obs_unit$obs_value)
  existe<-dbGetQuery(con, paste0("SELECT * FROM obs_unit"))
  if(nrow(existe)>0){obs_unit_new <- setdiff(obs_unit,existe[,names(obs_unit)])}
  if(nrow(existe)==0){obs_unit_new <- obs_unit}

  # sauvegarde vers la base de données
  if(nrow(obs_unit_new)==0){print('All obs_unit already presented in the database - none included')}
  if((nrow(obs_unit_new)>0)& (nrow(obs_unit_new)<nrow(obs_unit))){print('Some obs_unit were already presented in the database - only new included')}
  if(nrow(obs_unit_new)>0){
    DBI::dbWriteTable( con, "obs_unit", obs_unit_new, append = TRUE, overwrite = FALSE)
  }


  #----------------------------- WS TRIAL ----------------------------------###

  #    }else if(fich == "Weather_station_trial"){

  itable <- which(names(Aegis)=="Weather_station_trial")
  #renommer le fichier car il ne correspond pas ? une table de la bd
  ws_trial<-Aegis[[itable]]

  ws_trial<-(ws_trial[!duplicated(ws_trial$trial_code), ] )

  # renommer des colonnes
  ws_trial<-ws_trial%>%rename(wsname= weather_station_name)

  #wday
  ws_database<-import_database(con, "public.ws", c("wscode", "wsname"))

  # Faire la jointure pour récuprer la PK de ws
  jointure<-merge(ws_trial, ws_database, by ="wsname",all.x=T)

  #Supprimer la colonne inutile
  ws_trial <- dplyr::select(jointure, -wsname)
  ws_trial<-ws_trial%>%rename(trialcode= trial_code)

  # test pour ne garder que les lignes n'existant pas dans la BDD
  existe<-dbGetQuery(con, paste0("SELECT * FROM ws_trial"))
  if(nrow(existe)>0){ws_trial_new <- setdiff(ws_trial,existe[,names(ws_trial)])}
  if(nrow(existe)==0){ws_trial_new <- ws_trial}

  # sauvegarde dans la BDD
  if(nrow(ws_trial_new)==0){print('ws_trial already presented in the database - none included')}
  if((nrow(ws_trial_new)>0)& (nrow(ws_trial_new)<nrow(ws_trial))){print('Some ws_trial were already presented in the database - only new included')}
  if(nrow(ws_trial_new)>0){
    DBI::dbWriteTable( con, "ws_trial", ws_trial_new, append = TRUE, overwrite = FALSE)
  }



  #--------------------------  WEATHER DAYS -----------------------------------###

  #changer le format de date
  itable <- which(names(Aegis)=="Weather_day")
  Weather_day<- Aegis[[itable]]

  Weather_day$date=as.Date(Weather_day$date, format='%d/%m/%Y')

  # transposition des valeurs de certains champs en ligne
  wd <- Weather_day[,1:3];
  wd$weather_variable <- names(wd)[3]
  names(wd)[3] <- 'weather_value'
  for (i in 4:dim(Weather_day)[2]){
    wdtemp <- Weather_day[,c(1,2,i)]
    wdtemp$weather_variable <- names(wdtemp)[3]
    names(wdtemp)[3] <- 'weather_value'
    wd <- rbind(wd,wdtemp)
  }

  # renommer une colonne
  wd<-wd %>%rename(wsname = weather_station_name)
  wd<-wd %>%rename(weatherdate = date)

  #wday
  ws_database<-import_database(con, "public.ws", c("wscode", "wsname"))

  # Faire la jointure pour recuprer la PK
  jointure<-merge(wd, ws_database, by ="wsname")

  # suppression d'une colonne inutile wsname -#
  weather_day <- dplyr::select(jointure, -wsname)

  # test pour ne garder que les lignes n'existant pas déjà
  weather_day$weather_value <- as.numeric(weather_day$weather_value)
  existe<-dbGetQuery(con, paste0("SELECT * FROM weather_day"))
  if(nrow(existe)>0){weather_day_new <- setdiff(weather_day,existe[,names(weather_day)])}
  if(nrow(existe)==0){weather_day_new <- weather_day}

  # sauvegarde dans la BDD
  if(nrow(weather_day_new)==0){print('All weather_day already presented in the database - none included')}
  if((nrow(weather_day_new)>0)& (nrow(weather_day_new)<nrow(weather_day))){print('Some weather_day were already presented in the database - only new included')}
  if(nrow(weather_day_new)>0){
    # il faut incrémenter manuellement les id
    weather_day_id_max <- as.numeric(max(import_database(con,"public.weather_day" , c("wd_id"))$wd_id))
    if(weather_day_id_max< -1000){weather_day_id_max=1}
    weather_day_new$wd_id <- weather_day_id_max+(1:nrow(weather_day_new))

    DBI::dbWriteTable( con, "weather_day", weather_day_new, append = TRUE, overwrite = FALSE)
  }



  #--------------------------  lot_unit-----------------------------------###

  itable <- which(names(Aegis)=="Seedlot_Unit")
  Seedlot_unit<-Aegis[[itable]]

  # Changer le format de date pour qu'il corresponde à celui de la bd
  Seedlot_unit$gen_starting_date=as.Date(Seedlot_unit$gen_starting_date, format='%d/%m/%Y')

  # Changer le format de date pour qu'il corresponde ? celui de la bd
  Seedlot_unit$gen_ending_date=as.Date(Seedlot_unit$gen_ending_date, format='%d/%m/%Y')

  # renommer une colonne
  lot_unit<-Seedlot_unit %>%rename(sowing_date = gen_starting_date, ending_date = gen_ending_date)

  # récupérer les  id de la base de données
  exp_unit_database<- import_database(con, "public.exp_unit" ,
                                      c("unit_code", "exp_unit_id", "trial_code" ))

  # jointure pour ne récupérer que les id correspondants à notre trial code
  joint_exp_unit<-exp_unit_database %>% filter(trial_code %in% trial$trial_code)


  #jointure entre deux tables
  exp_unit_database1<-merge(lot_unit, joint_exp_unit, by ="unit_code")

  #jointure entre deux tables
  lot_database<- import_database(con, "public.lot", c("lot_id", "lot_code"))
  lot_unit<-merge(exp_unit_database1, lot_database, by ="lot_code")

  #--- suppression des colonnes inutiles   ----#
  lot_unit <- dplyr::select(lot_unit, -unit_code, -lot_code, -trial_code)

  # test pour ne garder que les lignes qui n'existent pas encore dans la BDD
  existe<-dbGetQuery(con, paste0("SELECT * FROM lot_unit"))
  if(nrow(existe)>0){lot_unit_new <- setdiff(lot_unit,existe[,names(lot_unit)])}
  if(nrow(existe)==0){lot_unit_new <- lot_unit}

  # sauvegarde
  if(nrow(lot_unit_new)==0){print('All lot_unit already presented in the database - none included')}
  if((nrow(lot_unit_new)>0)& (nrow(lot_unit_new)<nrow(lot_unit))){print('Some lot_unit were already presented in the database - only new included')}
  if(nrow(lot_unit_new)>0){
    DBI::dbWriteTable( con, "lot_unit", lot_unit_new, append = TRUE, overwrite = FALSE)
  }


  #------------------------------------Factor_unit---------------------########

  itable <- which(names(Aegis)=="Factor_Unit")
  Factor_Unit<-Aegis[[itable]]

  #changer le format de date
  Factor_Unit$from_date = as.Date(Factor_Unit$from_date, format='%d/%m/%Y')

  #changer le format de date
  Factor_Unit$to_date = as.Date(Factor_Unit$to_date, format='%d/%m/%Y')

  # suppression des colonnes pour ?viter les doublons
  Factor_Unit<-dplyr::select(Factor_Unit, -factor)

  # récupérer les  id de la base de données
  exp_unit_database<- import_database(con, "public.exp_unit" ,
                                      c("unit_code", "exp_unit_id", "trial_code" ))
  # jointure pour ne récupérer que les id correspondants à notre trial code
  joint_exp_unit<- exp_unit_database %>% filter(trial_code %in% trial$trial_code)

  Factor_Unit<- merge(Factor_Unit, joint_exp_unit, by="unit_code")

  factor_level_database<- import_database(con, "public.factor_level",
                                          c("factor_level_id", " factor_level" ))

  #jointure entre deux tables
  jointure<-merge(Factor_Unit, factor_level_database, by ="factor_level")

  #--- suppression des colonnes inutiles   ----#
  factor_unit <- dplyr::select(jointure, -unit_code,
                               -trial_code, -factor_level)

  # test pour ne garder que les lignes non présentes dans la database
  existe<-dbGetQuery(con, paste0("SELECT * FROM factor_unit"))
  if(nrow(existe)>0){factor_unit_new <- setdiff(factor_unit,existe[,names(factor_unit)])}
  if(nrow(existe)==0){factor_unit_new <- factor_unit}


  # sauvegarde
  if(nrow(factor_unit_new)==0){print('All factor_unit already presented in the database - none included')}
  if((nrow(factor_unit_new)>0)& (nrow(factor_unit_new)<nrow(factor_unit))){print('Some factor_unit were already presented in the database - only new included')}
  if(nrow(factor_unit_new)>0){
    DBI::dbWriteTable( con, "factor_unit", factor_unit_new, append = TRUE, overwrite = FALSE)
  }


  #---------------------------------ITK----------------------------------------#

  itable <- which(names(Aegis)=="Itk")
  Itk<- Aegis[[itable]]

  #changer le format de date
  Itk$itk_date = as.Date(Itk$itk_date, format='%d/%m/%Y')

  # récupérer les  id de la base de données
  exp_unit_database<- import_database(con, "public.exp_unit" ,
                                      c("unit_code", "exp_unit_id", "trial_code" ))


  # filtrer sur le trial code correspondant au projet en cours
  joint_exp_unit<- exp_unit_database %>% filter(trial_code %in% trial$trial_code)


  # faire une jointure pour recupérer les id de la table mère
  jointure1<- merge(joint_exp_unit, Itk, by="unit_code")

  # suppression d'une colonne inutile unit_code #
  itk<- dplyr::select(jointure1, -trial_code,  -unit_code, -itk_code)

  # test pour ne garder que les lignes non présentes dans la BDD
  itk$itk_value <- as.numeric(itk$itk_value)
  existe<-dbGetQuery(con, paste0("SELECT * FROM itk"))

  if(nrow(existe)>0){itk_new <- setdiff(itk,existe[,names(itk)])}
  if(nrow(existe)==0){itk_new <- itk}

  # sauvegarde
  if(nrow(itk_new)==0){print('All itk already presented in the database - none included')}
  if((nrow(itk_new)>0)& (nrow(itk_new)<nrow(itk))){print('Some itk were already presented in the database - only new included')}
  if(nrow(itk_new)>0){
    DBI::dbWriteTable( con, "itk", itk_new, append = TRUE, overwrite = FALSE)
  }

  #----------------------------------- product----------------------------------#
  itable <- which(names(Aegis)=="product")
  product<-Aegis[[itable]]

  # renommer la colonne name
  product<-product %>%rename(trading_name = product_name)

  # test pour ne garder que les lignes non présente dans la BDD
  existe<-dbGetQuery(con, paste0("SELECT * FROM product"))
  if(nrow(existe)>0){product_new <- setdiff(product,existe[,names(product)])}
  if(nrow(existe)==0){product_new <- product}

  # sauvegarde
  if(nrow(product_new)==0){print('All product already presented in the database - none included')}
  if((nrow(product_new)>0)& (nrow(product_new)<nrow(product))){print('Some product were already presented in the database - only new included')}
  if(nrow(product_new)>0){
    DBI::dbWriteTable( con, "product", product_new, append = TRUE, overwrite = FALSE)
  }


  #------------------------Itk_product ----------------------------------------#
  #    }else if(fich == "Ikt_product"){
  # itable <- which(names(Aegis)=="Itk_product")
  #
  # itk_product<- Aegis[[itable]]
  #
  # # renommer la colonne name
  # itk_product<-itk_product %>%rename(trading_name= product_name)
  #
  # # jointure avec product pour recuperer les id des produits
  # product_database<-import_database(con, "public.product", c("product_id", "trading_name"))
  #
  # Itk_p1<-merge(product_database, itk_product, by ="trading_name")
  #
  # # jointure pour récupérer les itk_id
  # # itk
  # itk_database<-import_database(con, "public.itk", c("itk_id", "itk_code"))
  #
  # Itk_p2<- merge(Itk_p1,itk_database, by= "itk_code",all.x=T,all.y=F)
  #
  # # supprimer les colonnes inutiles
  #
  # Itk_product<- dplyr::select(Itk_p2, -trading_name, - itk_code)
  #
  # # sauvegarde
  # #trait_sauve(con, "itk_product", Itk_product)
  # DBI::dbWriteTable( con, "itk_product", itk_product[i,], append = TRUE, overwrite = FALSE)
  # #----------------------------------- equipment---------------------------------#
  # #    }else if (fich =="equipement"){
  #
  # itable <- which(names(Aegis)=="equipement")
  # equipment<-Aegis[[itable]]
  #
  # # sauvegarde vers la base de données
  #
  # #trait_sauve(con, "equipment", equipment)
  # DBI::dbWriteTable( con, "equipment", equipment[i,], append = TRUE, overwrite = FALSE)
  #
  # #------------------------------------ Itk_equipment----------------------------#
  # #    }else if (fich == "Itk_equipment"){
  #
  # itable <- which(names(Aegis)=="Itk_equipment")
  # Itk_equipment<-Aegis[[itable]]
  #
  #
  # # itk
  # itk_database<-import_database(con, "public.itk", c("itk_id", "itk_code"))
  #
  # #equipment
  # equipment_database<-import_database(con, "public.equipment", c("equipment_id", "equipment_name"))
  #
  # # jointure pour récuperer les itk_id
  # Itk_equip1<-merge(Itk_equipment, itk_database, by="itk_code" )
  #
  # # jointure pour récupérer les id_equipment
  #
  # Itk_equip2<-merge(Itk_equip1, equipment_database, by= "equipment_name" )
  #
  # Itk_equipment<-dplyr::select(Itk_equip2, -itk_code, - equipment_name)
  #
  # # sauvegarde
  #
  # #trait_sauve(con, "itk_equipment", Itk_equipment)
  # DBI::dbWriteTable( con, "itk_equipment", itk_equipment[i,], append = TRUE, overwrite = FALSE)
  #
  # #---------------------------------------- operateur----------------------------#
  # #    }else if (fich =="operator"){
  #
  # itable <- which(names(Aegis)=="operator")
  # operator<-Aegis[[itable]]
  #
  #
  # #sauvegarde vers la base de données
  #
  # #trait_sauve(con, "operator", operator)
  # DBI::dbWriteTable( con, "operator", operator[i,], append = TRUE, overwrite = FALSE)
  #
  #
  # #----------------------------------- Itk_operateur----------------------------#
  # #    }else if (fich == "Itk_operator"){
  #
  # itable <- which(names(Aegis)=="Itk_operator")
  # itk_operator<- Aegis[[itable]]
  #
  # # itk
  # itk_database<-import_database(con, "public.itk", c("itk_id", "itk_code"))
  #
  # #operator
  # Op_database<-import_database(con, "public.operator", c("operator_code", "operator_id"))
  #
  #
  # # on récupère itk_id
  # itk_op<- merge(itk_database, itk_operator, by=" itk_code")
  #
  # #
  # itk_operator<-merge(itk_op, Op_database, by="operator_code")
  #
  # itk_operator<-dplyr::select(itk_operator, -itk_code, -operator_code)
  #
  # #trait_sauve(con, "itk_operator", itk_operator)
  # DBI::dbWriteTable( con, "itk_operator", itk_operator[i,], append = TRUE, overwrite = FALSE)


  #    }else{
  #     message(paste0("table ", fich, " est inconnue de notre base de données\n"))
  #    }
}
#}



