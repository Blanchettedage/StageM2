
#' Exportation
#'
#' Cette fonction permet, à partir d'un code d'essai ou d'un code d'essai,
#' de récupérer toutes les données propres à ce code qui se trouvent dans
#' les autres tables de la base de données et de les enregistrer sous forme
#' d'un fichier CSV dans l'emplacement de notre choix.
#'
#' @param trial_code Renseigne le code de l'essai pour lequel nous voulons collecter les donner
#' @param output_file permet de renseigner l'emplacement suivi du nom du fichier csv sous lequel nous voulons enregistrer nos données
#'
#' @return Cette fonction retourne un fichier de données csv
#' @export
#'
#' @examples
#'
#' #-- Exportation des données en fichier csv
#'
#' Export_database("canecoh_OF_2015_2016",
#'              "C:/Users/soumo/OneDrive/Bureau/data/canecoh_OF_2015_2016.csv")
#'
#' # Déconnexion de la base de données
#'
#'

Export_database <- function(trial_code, output_file) {

   User='postgres'
   mot_passe='dage'
   host_db='localhost'
   port_db=5432
   dbname='daphne_dev'

   con <- DBI::dbConnect(RPostgres::Postgres(), user=User, password=mot_passe,
   host=host_db, port=5432, dbnam = dbname)

  Query <- paste0("select trial.*,

                  rainweight,
                  weathweight,

                  unit_code,
                  surface,
                  nb_plant,
                  rowspace,
                  x_coord,
                  y_coord,
                  num_level,
                  level_label,
                  unit_alt,
                  unit_long,
                  assigned_to,
                  exp_unit_edge,
                  unit_depth,

                  site_name,
                  country,
                  site_lat,
                  site_long,
                  site_alt,

                  cultivation_method,
                  sowing_date,


                  itk_description,
                  itk_value,
                  itk_date,
                  itk_duration


                  from_date,
                  to_date,

                  lot_code,
                  lot_code_partner,
                  lot_description,

                  variable_code,
                  class,
                  subclass,
                  domain,
                  entry_date,
                  common_variable,
                  common_variable_code,


                  trait_name,
                  trait_description,
                  trait_author,
                  trait_target,

                  method_name,
                  method_class,
                  method_subclass,
                  method_description,
                  method_formula,
                  method_reference,
                  method_type,
                  content_type,


                  scale_name,
                  scale_type,
                  scale_level,

                  weatherdate,
                  weather_value,

                  factor_level,
                  factor,

                  wsname,
                  x_wgs84,
                  y_wgs84,
                  wslat,
                  wslong,
                  wsalt,
                  wstype,

                  accession_code,

                  entity_code,
                  entity_name,
                  entity_definition,

                  obs_date,
                  phytorank,
                  init,
                  obs_nb_objects,
                  obs_value

                  from public.trial
                  left join  ws_trial  ON ws_trial.trialcode=trial.trial_code
                  left join  exp_unit  ON exp_unit.trial_code= trial.trial_code
                  left join  site  ON site.site_code = trial.site_code
                  left join  itk ON itk.exp_unit_id= exp_unit.exp_unit_id
                  left join  factor_unit  ON factor_unit.exp_unit_id= exp_unit.exp_unit_id
                  left join  lot_unit ON lot_unit.exp_unit_id= exp_unit.exp_unit_id
                  left join  lot ON lot.lot_id= lot_unit.lot_id
                  left join  variable ON variable.variable_code= itk.itk_variable
                  left join  trait ON trait.trait_code= variable.trait_code
                  left join  method ON method.method_code = variable.method_code
                  left join  scale ON scale.scale_code= variable.scale_code
                  left join  factor_level ON factor_level.factor_level_id=factor_unit.factor_level_id
                  left join  factor ON factor.factor_id= factor_level.factor_id
                  left join  weather_day ON weather_day.weather_variable= variable.variable_code
                  left join  ws ON ws.wscode = ws_trial.wscode
                  left join  accession ON accession.accession_id = lot.accession_id
                  left join  taxo ON taxo.taxo_id = accession.taxo_id
                  left join  entity ON  entity.entity_code= trait.trait_entity
                  left join  obs_unit ON obs_unit.unit_id = exp_unit.exp_unit_id

                  where trial.trial_code='", trial_code, "'")

  essai <- DBI::dbGetQuery(con, Query)
  utils::write.csv2(essai, output_file, row.names = FALSE)

  DBI::dbDisconnect(con)
}


Export_database(trial_code = 'P41_2020_2021',output_file = 'C:/Users/soumo/OneDrive/Bureau/data/P41_New.csv')
