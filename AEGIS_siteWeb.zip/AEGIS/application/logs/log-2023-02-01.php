<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-02-01 06:44:43 --> Le chemin de destination semble invalide.
ERROR - 2023-02-01 08:06:11 --> Le chemin de destination semble invalide.
ERROR - 2023-02-01 08:11:44 --> Le chemin de destination semble invalide.
ERROR - 2023-02-01 07:12:01 --> 404 Page Not Found: Assets/css
ERROR - 2023-02-01 07:12:01 --> 404 Page Not Found: Assets/js
ERROR - 2023-02-01 11:49:57 --> Le chemin de destination semble invalide.
