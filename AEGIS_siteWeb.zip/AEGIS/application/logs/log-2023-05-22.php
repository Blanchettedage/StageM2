<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-22 06:18:34 --> 404 Page Not Found: Assets/images
ERROR - 2023-05-22 08:27:21 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given C:\wamp64\www\AEGIS\application\views\sample\new_sample.php 184
ERROR - 2023-05-22 08:31:13 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given C:\wamp64\www\AEGIS\application\views\sample\new_sample.php 184
ERROR - 2023-05-22 06:57:27 --> 404 Page Not Found: Assets/images
ERROR - 2023-05-22 06:59:34 --> 404 Page Not Found: Assets/images
ERROR - 2023-05-22 07:20:02 --> 404 Page Not Found: Assets/images
ERROR - 2023-05-22 07:58:40 --> 404 Page Not Found: Assets/images
ERROR - 2023-05-22 08:08:26 --> 404 Page Not Found: Assets/images
ERROR - 2023-05-22 11:40:14 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 11:40:14 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 11:40:14 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 11:40:14 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 11:40:14 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 11:40:14 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 11:40:14 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 11:40:14 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 11:40:14 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 11:40:14 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 11:40:14 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 11:40:14 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 11:40:14 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 11:40:14 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 11:40:14 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 11:40:14 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 11:40:14 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 11:40:14 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 11:40:14 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 11:40:14 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 12:22:32 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 12:22:32 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 12:22:32 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 12:22:32 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 12:22:32 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 12:22:32 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 12:22:32 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 12:22:32 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 12:22:32 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 12:22:32 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 12:22:33 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 12:22:33 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 12:22:33 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 12:22:33 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 12:22:33 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 12:22:33 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 12:22:33 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 12:22:33 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 12:22:33 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 12:22:33 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 10:35:49 --> 404 Page Not Found: Assets/images
ERROR - 2023-05-22 12:38:34 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 12:38:34 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 12:38:34 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 12:38:34 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 12:38:34 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 12:38:34 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 12:38:34 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 12:38:34 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 12:38:34 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 12:38:34 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 12:38:34 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 12:38:34 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 12:38:34 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 12:38:34 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 12:38:34 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 12:38:34 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 12:38:34 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 12:38:34 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 12:38:34 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 12:38:34 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 13:13:50 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 13:13:50 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 13:13:50 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 13:13:50 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 13:13:50 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 13:13:50 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 13:13:50 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 13:13:50 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 13:13:50 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 13:13:50 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 13:13:50 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 13:13:50 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 13:13:50 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 13:13:50 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 13:13:50 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 13:13:50 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 13:13:50 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 13:13:50 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 13:13:50 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 13:13:50 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-22 13:39:24 --> Severity: Warning --> Undefined property: Equipments::$Partner_model C:\wamp64\www\AEGIS\application\controllers\Equipments.php 36
ERROR - 2023-05-22 13:39:24 --> Severity: error --> Exception: Call to a member function count() on null C:\wamp64\www\AEGIS\application\controllers\Equipments.php 36
ERROR - 2023-05-22 13:43:29 --> Severity: Warning --> Undefined property: Equipments::$Equipement_model C:\wamp64\www\AEGIS\application\controllers\Equipments.php 36
ERROR - 2023-05-22 13:43:29 --> Severity: error --> Exception: Call to a member function count() on null C:\wamp64\www\AEGIS\application\controllers\Equipments.php 36
ERROR - 2023-05-22 13:44:01 --> Severity: Warning --> Undefined property: Equipments::$Equipement_model C:\wamp64\www\AEGIS\application\controllers\Equipments.php 36
ERROR - 2023-05-22 13:44:01 --> Severity: error --> Exception: Call to a member function count() on null C:\wamp64\www\AEGIS\application\controllers\Equipments.php 36
ERROR - 2023-05-22 13:49:03 --> Severity: Warning --> Undefined property: Equipments::$Equipments_model C:\wamp64\www\AEGIS\application\controllers\Equipments.php 54
ERROR - 2023-05-22 13:49:03 --> Severity: error --> Exception: Call to a member function find() on null C:\wamp64\www\AEGIS\application\controllers\Equipments.php 54
ERROR - 2023-05-22 13:50:29 --> 404 Page Not Found: 
ERROR - 2023-05-22 13:50:35 --> 404 Page Not Found: 
ERROR - 2023-05-22 14:03:44 --> 404 Page Not Found: 
ERROR - 2023-05-22 14:04:09 --> 404 Page Not Found: 
