<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-23 06:24:11 --> 404 Page Not Found: 
ERROR - 2023-05-23 06:48:29 --> 404 Page Not Found: 
ERROR - 2023-05-23 06:50:04 --> 404 Page Not Found: 
ERROR - 2023-05-23 06:50:06 --> 404 Page Not Found: 
ERROR - 2023-05-23 06:50:07 --> 404 Page Not Found: 
ERROR - 2023-05-23 06:50:07 --> 404 Page Not Found: 
ERROR - 2023-05-23 06:50:12 --> 404 Page Not Found: 
ERROR - 2023-05-23 06:50:30 --> 404 Page Not Found: 
ERROR - 2023-05-23 07:04:27 --> 404 Page Not Found: 
ERROR - 2023-05-23 07:24:59 --> Severity: Warning --> Undefined variable $equipements C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 35
ERROR - 2023-05-23 07:24:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 35
ERROR - 2023-05-23 07:24:59 --> Severity: Warning --> Undefined variable $equipements C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 35
ERROR - 2023-05-23 07:24:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 35
ERROR - 2023-05-23 07:25:32 --> Severity: Warning --> Undefined variable $equipements C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 35
ERROR - 2023-05-23 07:25:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 35
ERROR - 2023-05-23 07:25:33 --> Severity: Warning --> Undefined variable $equipements C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 35
ERROR - 2023-05-23 07:25:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 35
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 39
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 39
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 40
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 40
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 41
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 41
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 39
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 39
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 40
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 40
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 41
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 41
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 39
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 39
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 40
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 40
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 41
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 41
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 39
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 39
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 40
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 40
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 41
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 41
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 39
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 39
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 40
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 40
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 41
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 41
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 39
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 39
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 40
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 40
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 41
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 41
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 39
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 39
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 40
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 40
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 41
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 41
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 39
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 39
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 40
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 40
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 41
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 41
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 39
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 39
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 40
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 40
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 41
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 41
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 39
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 39
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 40
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 40
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 41
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 41
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 39
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 39
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 40
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 40
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 41
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 41
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 39
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 39
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 40
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 40
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 41
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 41
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 39
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 39
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 40
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 40
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 41
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 41
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 39
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 39
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 40
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 40
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 41
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 41
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 39
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 39
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 40
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 40
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 41
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 41
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 39
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 39
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 40
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 40
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 41
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 41
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 39
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 39
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 40
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 40
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 41
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 41
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 39
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 39
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 40
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 40
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 41
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 41
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 39
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 39
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 40
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 40
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 41
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 41
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 39
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 39
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 40
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 40
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Undefined variable $equipement C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 41
ERROR - 2023-05-23 07:26:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\equipment\equipments.php 41
ERROR - 2023-05-23 05:32:42 --> 404 Page Not Found: Equipments/10
ERROR - 2023-05-23 05:32:47 --> 404 Page Not Found: Equipments/10
ERROR - 2023-05-23 05:32:53 --> 404 Page Not Found: Equipments/10
ERROR - 2023-05-23 07:34:31 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 07:34:31 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 07:34:31 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 07:34:31 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 07:34:31 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 07:34:31 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 07:34:31 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 07:34:31 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 07:34:31 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 07:34:31 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 07:34:31 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 07:34:31 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 07:34:31 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 07:34:31 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 07:34:31 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 07:34:31 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 07:34:31 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 07:34:31 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 07:34:31 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 07:34:31 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 07:45:42 --> Severity: Warning --> Undefined variable $offset C:\wamp64\www\AEGIS\application\controllers\Products.php 31
ERROR - 2023-05-23 07:45:42 --> Severity: Warning --> Undefined property: Products::$Equipment_model C:\wamp64\www\AEGIS\application\controllers\Products.php 54
ERROR - 2023-05-23 07:45:42 --> Severity: error --> Exception: Call to a member function find() on null C:\wamp64\www\AEGIS\application\controllers\Products.php 54
ERROR - 2023-05-23 07:49:08 --> Severity: Warning --> Undefined variable $offset C:\wamp64\www\AEGIS\application\controllers\Products.php 31
ERROR - 2023-05-23 07:49:09 --> Severity: Warning --> Undefined variable $offset C:\wamp64\www\AEGIS\application\controllers\Products.php 31
ERROR - 2023-05-23 07:54:48 --> Severity: Warning --> Undefined variable $offset C:\wamp64\www\AEGIS\application\controllers\Products.php 31
ERROR - 2023-05-23 07:54:48 --> Severity: Warning --> Undefined variable $offset C:\wamp64\www\AEGIS\application\controllers\Products.php 31
ERROR - 2023-05-23 07:54:53 --> Severity: Warning --> Undefined variable $offset C:\wamp64\www\AEGIS\application\controllers\Products.php 31
ERROR - 2023-05-23 07:54:54 --> Severity: Warning --> Undefined variable $offset C:\wamp64\www\AEGIS\application\controllers\Products.php 31
ERROR - 2023-05-23 07:56:21 --> Severity: Warning --> Undefined variable $offset C:\wamp64\www\AEGIS\application\controllers\Products.php 31
ERROR - 2023-05-23 07:56:21 --> Severity: Warning --> Undefined variable $offset C:\wamp64\www\AEGIS\application\controllers\Products.php 31
ERROR - 2023-05-23 07:56:27 --> Severity: Warning --> Undefined variable $offset C:\wamp64\www\AEGIS\application\controllers\Products.php 31
ERROR - 2023-05-23 07:56:27 --> Severity: Warning --> Undefined variable $offset C:\wamp64\www\AEGIS\application\controllers\Products.php 31
ERROR - 2023-05-23 07:57:29 --> Severity: Warning --> Undefined array key "offset" C:\wamp64\www\AEGIS\application\controllers\Products.php 54
ERROR - 2023-05-23 07:57:29 --> Severity: Warning --> Undefined array key "offset" C:\wamp64\www\AEGIS\application\controllers\Products.php 54
ERROR - 2023-05-23 07:59:29 --> Could not find the language line "form_validation_less_than"
ERROR - 2023-05-23 08:01:06 --> Could not find the language line "form_validation_less_than"
ERROR - 2023-05-23 08:01:28 --> Could not find the language line "form_validation_less_than"
ERROR - 2023-05-23 08:01:29 --> Could not find the language line "form_validation_less_than"
ERROR - 2023-05-23 08:01:30 --> Could not find the language line "form_validation_less_than"
ERROR - 2023-05-23 08:01:33 --> Could not find the language line "form_validation_less_than"
ERROR - 2023-05-23 06:02:13 --> Severity: error --> Exception: syntax error, unexpected token "<", expecting ")" C:\wamp64\www\AEGIS\application\controllers\Products.php 24
ERROR - 2023-05-23 08:02:31 --> Could not find the language line "form_validation_is_natural"
ERROR - 2023-05-23 08:02:48 --> Could not find the language line "form_validation_less_than"
ERROR - 2023-05-23 08:03:49 --> Severity: error --> Exception: Too few arguments to function Products::index(), 0 passed in C:\wamp64\www\AEGIS\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\wamp64\www\AEGIS\application\controllers\Products.php 24
ERROR - 2023-05-23 08:04:10 --> Could not find the language line "form_validation_less_than"
ERROR - 2023-05-23 08:26:38 --> Severity: Warning --> Undefined variable $products C:\wamp64\www\AEGIS\application\views\operator\operators.php 35
ERROR - 2023-05-23 08:26:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\wamp64\www\AEGIS\application\views\operator\operators.php 35
ERROR - 2023-05-23 08:26:38 --> Severity: Warning --> Undefined variable $products C:\wamp64\www\AEGIS\application\views\operator\operators.php 35
ERROR - 2023-05-23 08:26:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\wamp64\www\AEGIS\application\views\operator\operators.php 35
ERROR - 2023-05-23 08:33:31 --> Severity: Warning --> Undefined variable $products C:\wamp64\www\AEGIS\application\views\operator\operators.php 35
ERROR - 2023-05-23 08:33:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\wamp64\www\AEGIS\application\views\operator\operators.php 35
ERROR - 2023-05-23 08:33:32 --> Severity: Warning --> Undefined variable $products C:\wamp64\www\AEGIS\application\views\operator\operators.php 35
ERROR - 2023-05-23 08:33:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\wamp64\www\AEGIS\application\views\operator\operators.php 35
ERROR - 2023-05-23 08:33:35 --> Severity: Warning --> Undefined variable $products C:\wamp64\www\AEGIS\application\views\operator\operators.php 35
ERROR - 2023-05-23 08:33:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\wamp64\www\AEGIS\application\views\operator\operators.php 35
ERROR - 2023-05-23 08:33:35 --> Severity: Warning --> Undefined variable $products C:\wamp64\www\AEGIS\application\views\operator\operators.php 35
ERROR - 2023-05-23 08:33:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\wamp64\www\AEGIS\application\views\operator\operators.php 35
ERROR - 2023-05-23 08:35:27 --> Severity: Warning --> Undefined variable $equipment C:\wamp64\www\AEGIS\application\views\operator\operators.php 39
ERROR - 2023-05-23 08:35:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\operator\operators.php 39
ERROR - 2023-05-23 08:35:27 --> Severity: Warning --> Undefined variable $equipment C:\wamp64\www\AEGIS\application\views\operator\operators.php 40
ERROR - 2023-05-23 08:35:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\operator\operators.php 40
ERROR - 2023-05-23 08:35:27 --> Severity: Warning --> Undefined variable $equipment C:\wamp64\www\AEGIS\application\views\operator\operators.php 41
ERROR - 2023-05-23 08:35:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\operator\operators.php 41
ERROR - 2023-05-23 08:35:27 --> Severity: Warning --> Undefined variable $equipment C:\wamp64\www\AEGIS\application\views\operator\operators.php 39
ERROR - 2023-05-23 08:35:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\operator\operators.php 39
ERROR - 2023-05-23 08:35:27 --> Severity: Warning --> Undefined variable $equipment C:\wamp64\www\AEGIS\application\views\operator\operators.php 40
ERROR - 2023-05-23 08:35:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\operator\operators.php 40
ERROR - 2023-05-23 08:35:27 --> Severity: Warning --> Undefined variable $equipment C:\wamp64\www\AEGIS\application\views\operator\operators.php 41
ERROR - 2023-05-23 08:35:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\operator\operators.php 41
ERROR - 2023-05-23 08:35:27 --> Severity: Warning --> Undefined variable $equipment C:\wamp64\www\AEGIS\application\views\operator\operators.php 39
ERROR - 2023-05-23 08:35:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\operator\operators.php 39
ERROR - 2023-05-23 08:35:27 --> Severity: Warning --> Undefined variable $equipment C:\wamp64\www\AEGIS\application\views\operator\operators.php 40
ERROR - 2023-05-23 08:35:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\operator\operators.php 40
ERROR - 2023-05-23 08:35:27 --> Severity: Warning --> Undefined variable $equipment C:\wamp64\www\AEGIS\application\views\operator\operators.php 41
ERROR - 2023-05-23 08:35:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\operator\operators.php 41
ERROR - 2023-05-23 08:35:27 --> Severity: Warning --> Undefined variable $equipment C:\wamp64\www\AEGIS\application\views\operator\operators.php 39
ERROR - 2023-05-23 08:35:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\operator\operators.php 39
ERROR - 2023-05-23 08:35:27 --> Severity: Warning --> Undefined variable $equipment C:\wamp64\www\AEGIS\application\views\operator\operators.php 40
ERROR - 2023-05-23 08:35:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\operator\operators.php 40
ERROR - 2023-05-23 08:35:27 --> Severity: Warning --> Undefined variable $equipment C:\wamp64\www\AEGIS\application\views\operator\operators.php 41
ERROR - 2023-05-23 08:35:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\operator\operators.php 41
ERROR - 2023-05-23 08:35:27 --> Severity: Warning --> Undefined variable $equipment C:\wamp64\www\AEGIS\application\views\operator\operators.php 39
ERROR - 2023-05-23 08:35:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\operator\operators.php 39
ERROR - 2023-05-23 08:35:27 --> Severity: Warning --> Undefined variable $equipment C:\wamp64\www\AEGIS\application\views\operator\operators.php 40
ERROR - 2023-05-23 08:35:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\operator\operators.php 40
ERROR - 2023-05-23 08:35:27 --> Severity: Warning --> Undefined variable $equipment C:\wamp64\www\AEGIS\application\views\operator\operators.php 41
ERROR - 2023-05-23 08:35:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\operator\operators.php 41
ERROR - 2023-05-23 08:35:27 --> Severity: Warning --> Undefined variable $equipment C:\wamp64\www\AEGIS\application\views\operator\operators.php 39
ERROR - 2023-05-23 08:35:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\operator\operators.php 39
ERROR - 2023-05-23 08:35:27 --> Severity: Warning --> Undefined variable $equipment C:\wamp64\www\AEGIS\application\views\operator\operators.php 40
ERROR - 2023-05-23 08:35:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\operator\operators.php 40
ERROR - 2023-05-23 08:35:27 --> Severity: Warning --> Undefined variable $equipment C:\wamp64\www\AEGIS\application\views\operator\operators.php 41
ERROR - 2023-05-23 08:35:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\operator\operators.php 41
ERROR - 2023-05-23 08:35:27 --> Severity: Warning --> Undefined variable $equipment C:\wamp64\www\AEGIS\application\views\operator\operators.php 39
ERROR - 2023-05-23 08:35:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\operator\operators.php 39
ERROR - 2023-05-23 08:35:27 --> Severity: Warning --> Undefined variable $equipment C:\wamp64\www\AEGIS\application\views\operator\operators.php 40
ERROR - 2023-05-23 08:35:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\operator\operators.php 40
ERROR - 2023-05-23 08:35:27 --> Severity: Warning --> Undefined variable $equipment C:\wamp64\www\AEGIS\application\views\operator\operators.php 41
ERROR - 2023-05-23 08:35:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\operator\operators.php 41
ERROR - 2023-05-23 08:35:28 --> Severity: Warning --> Undefined variable $equipment C:\wamp64\www\AEGIS\application\views\operator\operators.php 39
ERROR - 2023-05-23 08:35:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\operator\operators.php 39
ERROR - 2023-05-23 08:35:28 --> Severity: Warning --> Undefined variable $equipment C:\wamp64\www\AEGIS\application\views\operator\operators.php 40
ERROR - 2023-05-23 08:35:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\operator\operators.php 40
ERROR - 2023-05-23 08:35:28 --> Severity: Warning --> Undefined variable $equipment C:\wamp64\www\AEGIS\application\views\operator\operators.php 41
ERROR - 2023-05-23 08:35:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\operator\operators.php 41
ERROR - 2023-05-23 08:35:28 --> Severity: Warning --> Undefined variable $equipment C:\wamp64\www\AEGIS\application\views\operator\operators.php 39
ERROR - 2023-05-23 08:35:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\operator\operators.php 39
ERROR - 2023-05-23 08:35:28 --> Severity: Warning --> Undefined variable $equipment C:\wamp64\www\AEGIS\application\views\operator\operators.php 40
ERROR - 2023-05-23 08:35:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\operator\operators.php 40
ERROR - 2023-05-23 08:35:28 --> Severity: Warning --> Undefined variable $equipment C:\wamp64\www\AEGIS\application\views\operator\operators.php 41
ERROR - 2023-05-23 08:35:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\operator\operators.php 41
ERROR - 2023-05-23 08:35:28 --> Severity: Warning --> Undefined variable $equipment C:\wamp64\www\AEGIS\application\views\operator\operators.php 39
ERROR - 2023-05-23 08:35:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\operator\operators.php 39
ERROR - 2023-05-23 08:35:28 --> Severity: Warning --> Undefined variable $equipment C:\wamp64\www\AEGIS\application\views\operator\operators.php 40
ERROR - 2023-05-23 08:35:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\operator\operators.php 40
ERROR - 2023-05-23 08:35:28 --> Severity: Warning --> Undefined variable $equipment C:\wamp64\www\AEGIS\application\views\operator\operators.php 41
ERROR - 2023-05-23 08:35:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\operator\operators.php 41
ERROR - 2023-05-23 08:35:28 --> Severity: Warning --> Undefined variable $equipment C:\wamp64\www\AEGIS\application\views\operator\operators.php 39
ERROR - 2023-05-23 08:35:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\operator\operators.php 39
ERROR - 2023-05-23 08:35:28 --> Severity: Warning --> Undefined variable $equipment C:\wamp64\www\AEGIS\application\views\operator\operators.php 40
ERROR - 2023-05-23 08:35:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\operator\operators.php 40
ERROR - 2023-05-23 08:35:28 --> Severity: Warning --> Undefined variable $equipment C:\wamp64\www\AEGIS\application\views\operator\operators.php 41
ERROR - 2023-05-23 08:35:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\operator\operators.php 41
ERROR - 2023-05-23 08:35:28 --> Severity: Warning --> Undefined variable $equipment C:\wamp64\www\AEGIS\application\views\operator\operators.php 39
ERROR - 2023-05-23 08:35:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\operator\operators.php 39
ERROR - 2023-05-23 08:35:28 --> Severity: Warning --> Undefined variable $equipment C:\wamp64\www\AEGIS\application\views\operator\operators.php 40
ERROR - 2023-05-23 08:35:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\operator\operators.php 40
ERROR - 2023-05-23 08:35:28 --> Severity: Warning --> Undefined variable $equipment C:\wamp64\www\AEGIS\application\views\operator\operators.php 41
ERROR - 2023-05-23 08:35:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\operator\operators.php 41
ERROR - 2023-05-23 08:35:28 --> Severity: Warning --> Undefined variable $equipment C:\wamp64\www\AEGIS\application\views\operator\operators.php 39
ERROR - 2023-05-23 08:35:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\operator\operators.php 39
ERROR - 2023-05-23 08:35:28 --> Severity: Warning --> Undefined variable $equipment C:\wamp64\www\AEGIS\application\views\operator\operators.php 40
ERROR - 2023-05-23 08:35:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\operator\operators.php 40
ERROR - 2023-05-23 08:35:28 --> Severity: Warning --> Undefined variable $equipment C:\wamp64\www\AEGIS\application\views\operator\operators.php 41
ERROR - 2023-05-23 08:35:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\operator\operators.php 41
ERROR - 2023-05-23 08:35:28 --> Severity: Warning --> Undefined variable $equipment C:\wamp64\www\AEGIS\application\views\operator\operators.php 39
ERROR - 2023-05-23 08:35:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\operator\operators.php 39
ERROR - 2023-05-23 08:35:28 --> Severity: Warning --> Undefined variable $equipment C:\wamp64\www\AEGIS\application\views\operator\operators.php 40
ERROR - 2023-05-23 08:35:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\operator\operators.php 40
ERROR - 2023-05-23 08:35:28 --> Severity: Warning --> Undefined variable $equipment C:\wamp64\www\AEGIS\application\views\operator\operators.php 41
ERROR - 2023-05-23 08:35:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\views\operator\operators.php 41
ERROR - 2023-05-23 08:42:07 --> Could not find the language line "form_validation_less_than"
ERROR - 2023-05-23 09:18:38 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 09:18:38 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 09:18:38 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 09:18:38 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 09:18:38 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 09:18:38 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 09:18:38 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 09:18:38 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 09:18:38 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 09:18:38 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 09:18:38 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 09:18:38 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 09:18:38 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 09:18:38 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 09:18:38 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 09:18:38 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 09:18:38 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 09:18:38 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 09:18:38 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 09:18:38 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 09:41:23 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 09:41:23 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 09:41:23 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 09:41:23 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 09:41:23 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 09:41:23 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 09:41:23 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 09:41:23 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 09:41:23 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 09:41:23 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 09:41:23 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 09:41:23 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 09:41:23 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 09:41:23 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 09:41:23 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 09:41:23 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 09:41:23 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 09:41:23 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 09:41:23 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-05-23 09:41:23 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
