<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-16 08:34:41 --> Severity: Warning --> session_destroy(): Trying to destroy uninitialized session C:\wamp64\www\AEGIS\system\libraries\Session\Session.php 702
ERROR - 2023-05-16 08:38:50 --> Severity: Warning --> session_destroy(): Trying to destroy uninitialized session C:\wamp64\www\AEGIS\system\libraries\Session\Session.php 702
ERROR - 2023-05-16 09:39:21 --> 404 Page Not Found: Assets/images
ERROR - 2023-05-16 09:54:09 --> 404 Page Not Found: Assets/images
