<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-17 09:31:36 --> 404 Page Not Found: Package/telechargement
ERROR - 2023-05-17 09:31:44 --> 404 Page Not Found: Package/telechargement
ERROR - 2023-05-17 09:31:53 --> 404 Page Not Found: Package/telechargement
ERROR - 2023-05-17 09:32:01 --> 404 Page Not Found: Package/telechargement
ERROR - 2023-05-17 09:32:14 --> 404 Page Not Found: Package/telechargement
ERROR - 2023-05-17 09:35:20 --> 404 Page Not Found: Package/telechargement
ERROR - 2023-05-17 10:03:58 --> Severity: error --> Exception: Unclosed '{' on line 4 C:\wamp64\www\AEGIS\application\controllers\Package.php 152
ERROR - 2023-05-17 10:05:41 --> Severity: Compile Error --> Cannot redeclare Package::download_form() C:\wamp64\www\AEGIS\application\controllers\Package.php 80
ERROR - 2023-05-17 11:03:40 --> 404 Page Not Found: Package/telechargement
ERROR - 2023-05-17 11:13:35 --> 404 Page Not Found: Package/telechargement
ERROR - 2023-05-17 11:14:26 --> 404 Page Not Found: Package/telechargement
ERROR - 2023-05-17 11:14:47 --> 404 Page Not Found: Package/telechargement
ERROR - 2023-05-17 13:29:02 --> Severity: Warning --> Undefined variable $page C:\wamp64\www\AEGIS\application\controllers\Package.php 48
ERROR - 2023-05-17 13:29:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\controllers\Package.php 48
ERROR - 2023-05-17 13:29:02 --> Severity: Warning --> Undefined variable $page C:\wamp64\www\AEGIS\application\controllers\Package.php 48
ERROR - 2023-05-17 13:29:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\controllers\Package.php 48
ERROR - 2023-05-17 13:29:02 --> Severity: Warning --> Undefined variable $page C:\wamp64\www\AEGIS\application\controllers\Package.php 48
ERROR - 2023-05-17 13:29:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\controllers\Package.php 48
ERROR - 2023-05-17 13:29:02 --> Severity: Warning --> Undefined variable $page C:\wamp64\www\AEGIS\application\controllers\Package.php 48
ERROR - 2023-05-17 13:29:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\controllers\Package.php 48
ERROR - 2023-05-17 13:29:07 --> Severity: Warning --> Undefined variable $page C:\wamp64\www\AEGIS\application\controllers\Package.php 48
ERROR - 2023-05-17 13:29:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\controllers\Package.php 48
ERROR - 2023-05-17 13:29:07 --> Severity: Warning --> Undefined variable $page C:\wamp64\www\AEGIS\application\controllers\Package.php 48
ERROR - 2023-05-17 13:29:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\controllers\Package.php 48
ERROR - 2023-05-17 13:29:07 --> Severity: Warning --> Undefined variable $page C:\wamp64\www\AEGIS\application\controllers\Package.php 48
ERROR - 2023-05-17 13:29:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\controllers\Package.php 48
ERROR - 2023-05-17 13:29:07 --> Severity: Warning --> Undefined variable $page C:\wamp64\www\AEGIS\application\controllers\Package.php 48
ERROR - 2023-05-17 13:29:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\AEGIS\application\controllers\Package.php 48
ERROR - 2023-05-17 13:37:57 --> 404 Page Not Found: 
ERROR - 2023-05-17 13:38:00 --> 404 Page Not Found: 
