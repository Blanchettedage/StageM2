<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-02-13 06:40:42 --> Severity: Warning --> session_destroy(): Trying to destroy uninitialized session C:\wamp64\www\AEGIS\system\libraries\Session\Session.php 702
ERROR - 2023-02-13 06:41:55 --> Severity: Warning --> session_destroy(): Trying to destroy uninitialized session C:\wamp64\www\AEGIS\system\libraries\Session\Session.php 702
ERROR - 2023-02-13 05:42:26 --> 404 Page Not Found: Assets/images
ERROR - 2023-02-13 05:44:00 --> 404 Page Not Found: Assets/images
ERROR - 2023-02-13 06:37:14 --> 404 Page Not Found: Assets/images
ERROR - 2023-02-13 08:05:56 --> 404 Page Not Found: Assets/images
ERROR - 2023-02-13 08:11:41 --> 404 Page Not Found: Assets/images
ERROR - 2023-02-13 09:14:45 --> Could not find the language line "form_validation_regex_match"
ERROR - 2023-02-13 08:14:45 --> 404 Page Not Found: Assets/images
ERROR - 2023-02-13 08:16:09 --> 404 Page Not Found: Assets/images
ERROR - 2023-02-13 09:18:16 --> Severity: Warning --> pg_query(): Query failed: ERREUR:  la valeur d'une clé dupliquée rompt la contrainte unique « bff_trial_pkey »
DETAIL:  La clé « (trial_code)=(canecoh_OF_2015_2016) » existe déjà. C:\wamp64\www\AEGIS\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2023-02-13 09:18:16 --> Query error: ERREUR:  la valeur d'une clé dupliquée rompt la contrainte unique « bff_trial_pkey »
DETAIL:  La clé « (trial_code)=(canecoh_OF_2015_2016) » existe déjà. - Invalid query: INSERT INTO "trial" ("trial_code", "site_code", "trial_description", "starting_date", "ending_date", "commentary", "controlled_environment") VALUES ('canecoh_OF_2015_2016', NULL, NULL, '2015-01-01', '2016-01-01', NULL, 'f')
ERROR - 2023-02-13 09:27:36 --> 404 Page Not Found: Assets/images
ERROR - 2023-02-13 09:30:44 --> 404 Page Not Found: Assets/images
ERROR - 2023-02-13 09:30:47 --> 404 Page Not Found: Assets/images
ERROR - 2023-02-13 09:30:48 --> 404 Page Not Found: Assets/images
ERROR - 2023-02-13 10:31:37 --> Severity: Warning --> session_destroy(): Trying to destroy uninitialized session C:\wamp64\www\AEGIS\system\libraries\Session\Session.php 702
ERROR - 2023-02-13 09:31:57 --> 404 Page Not Found: Assets/images
ERROR - 2023-02-13 09:58:28 --> 404 Page Not Found: Assets/images
ERROR - 2023-02-13 10:00:26 --> 404 Page Not Found: Assets/images
ERROR - 2023-02-13 11:51:41 --> Severity: Warning --> session_destroy(): Trying to destroy uninitialized session C:\wamp64\www\AEGIS\system\libraries\Session\Session.php 702
ERROR - 2023-02-13 10:52:49 --> 404 Page Not Found: Assets/images
ERROR - 2023-02-13 11:54:53 --> Severity: Warning --> pg_query(): Query failed: ERREUR:  la valeur d'une clé dupliquée rompt la contrainte unique « bff_trial_pkey »
DETAIL:  La clé « (trial_code)=(canecoh_OF_2017_2018) » existe déjà. C:\wamp64\www\AEGIS\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2023-02-13 11:54:53 --> Query error: ERREUR:  la valeur d'une clé dupliquée rompt la contrainte unique « bff_trial_pkey »
DETAIL:  La clé « (trial_code)=(canecoh_OF_2017_2018) » existe déjà. - Invalid query: INSERT INTO "trial" ("trial_code", "site_code", "trial_description", "starting_date", "ending_date", "commentary", "controlled_environment") VALUES ('canecoh_OF_2017_2018', NULL, NULL, '2017-01-01', '2018-01-01', NULL, 'f')
ERROR - 2023-02-13 12:01:40 --> Severity: Warning --> pg_query(): Query failed: ERREUR:  la valeur d'une clé dupliquée rompt la contrainte unique « bff_trial_pkey »
DETAIL:  La clé « (trial_code)=(canecoh_OF_2017_2018) » existe déjà. C:\wamp64\www\AEGIS\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2023-02-13 12:01:40 --> Query error: ERREUR:  la valeur d'une clé dupliquée rompt la contrainte unique « bff_trial_pkey »
DETAIL:  La clé « (trial_code)=(canecoh_OF_2017_2018) » existe déjà. - Invalid query: INSERT INTO "trial" ("trial_code", "site_code", "trial_description", "starting_date", "ending_date", "commentary", "controlled_environment") VALUES ('canecoh_OF_2017_2018', NULL, NULL, '2017-01-01', '2018-01-01', NULL, 'f')
ERROR - 2023-02-13 12:02:18 --> Severity: Warning --> session_destroy(): Trying to destroy uninitialized session C:\wamp64\www\AEGIS\system\libraries\Session\Session.php 702
ERROR - 2023-02-13 11:03:33 --> 404 Page Not Found: Assets/images
ERROR - 2023-02-13 11:03:43 --> 404 Page Not Found: Assets/css
ERROR - 2023-02-13 11:03:43 --> 404 Page Not Found: Assets/js
ERROR - 2023-02-13 11:04:44 --> 404 Page Not Found: Assets/css
ERROR - 2023-02-13 11:04:44 --> 404 Page Not Found: Assets/images
ERROR - 2023-02-13 11:04:44 --> 404 Page Not Found: Assets/js
ERROR - 2023-02-13 11:05:04 --> 404 Page Not Found: Assets/css
ERROR - 2023-02-13 11:05:04 --> 404 Page Not Found: Assets/js
ERROR - 2023-02-13 12:31:25 --> Could not find the language line "form_validation_regex_match"
ERROR - 2023-02-13 12:31:25 --> Could not find the language line "form_validation_regex_match"
ERROR - 2023-02-13 12:45:18 --> Could not find the language line "form_validation_required"
ERROR - 2023-02-13 12:45:34 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given C:\wamp64\www\AEGIS\application\controllers\Projects.php 295
ERROR - 2023-02-13 12:46:00 --> Could not find the language line "form_validation_is_unique"
ERROR - 2023-02-13 11:46:43 --> 404 Page Not Found: Assets/images
ERROR - 2023-02-13 12:48:13 --> Could not find the language line "form_validation_regex_match"
ERROR - 2023-02-13 11:48:13 --> 404 Page Not Found: Assets/images
