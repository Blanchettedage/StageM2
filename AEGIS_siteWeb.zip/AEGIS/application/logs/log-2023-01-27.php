<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-01-27 06:01:28 --> Could not find the language line "form_validation_alpha_dash"
ERROR - 2023-01-27 06:01:38 --> Could not find the language line "form_validation_required"
ERROR - 2023-01-27 06:01:38 --> Could not find the language line "form_validation_required"
ERROR - 2023-01-27 06:01:38 --> Could not find the language line "form_validation_alpha_dash"
ERROR - 2023-01-27 06:02:01 --> Could not find the language line "form_validation_alpha_dash"
ERROR - 2023-01-27 06:02:31 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp64\www\AEGIS\system\libraries\Email.php 1902
