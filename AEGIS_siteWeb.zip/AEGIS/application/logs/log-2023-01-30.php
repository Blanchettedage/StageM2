<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-01-30 06:46:00 --> Severity: Warning --> session_destroy(): Trying to destroy uninitialized session C:\wamp64\www\AEGIS\system\libraries\Session\Session.php 702
ERROR - 2023-01-30 06:47:07 --> Severity: Warning --> session_destroy(): Trying to destroy uninitialized session C:\wamp64\www\AEGIS\system\libraries\Session\Session.php 702
ERROR - 2023-01-30 06:47:49 --> Severity: Warning --> session_destroy(): Trying to destroy uninitialized session C:\wamp64\www\AEGIS\system\libraries\Session\Session.php 702
ERROR - 2023-01-30 07:29:28 --> Severity: Warning --> session_destroy(): Trying to destroy uninitialized session C:\wamp64\www\AEGIS\system\libraries\Session\Session.php 702
ERROR - 2023-01-30 07:45:01 --> Severity: Warning --> session_destroy(): Trying to destroy uninitialized session C:\wamp64\www\AEGIS\system\libraries\Session\Session.php 702
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "trait_name" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 155
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "trait_entity" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 157
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "trait_target" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 159
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "method_class" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 165
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "method_name" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 167
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "method_formula" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 169
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "model_variable_unit" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 171
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "scale_type" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 173
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "trait_name" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 155
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "trait_entity" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 157
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "trait_target" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 159
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "method_class" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 165
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "method_name" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 167
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "method_formula" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 169
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "model_variable_unit" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 171
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "scale_type" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 173
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "trait_name" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 155
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "trait_entity" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 157
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "trait_target" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 159
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "method_class" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 165
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "method_name" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 167
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "method_formula" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 169
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "model_variable_unit" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 171
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "scale_type" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 173
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "trait_name" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 155
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "trait_entity" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 157
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "trait_target" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 159
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "method_class" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 165
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "method_name" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 167
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "method_formula" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 169
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "model_variable_unit" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 171
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "scale_type" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 173
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "trait_name" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 155
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "trait_entity" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 157
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "trait_target" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 159
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "method_class" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 165
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "method_name" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 167
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "method_formula" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 169
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "model_variable_unit" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 171
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "scale_type" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 173
ERROR - 2023-01-30 07:18:45 --> 404 Page Not Found: Assets/images
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "trait_name" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 155
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "trait_entity" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 157
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "trait_target" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 159
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "method_class" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 165
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "method_name" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 167
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "method_formula" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 169
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "model_variable_unit" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 171
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "scale_type" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 173
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "trait_name" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 155
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "trait_entity" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 157
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "trait_target" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 159
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "method_class" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 165
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "method_name" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 167
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "method_formula" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 169
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "model_variable_unit" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 171
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "scale_type" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 173
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "trait_name" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 155
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "trait_entity" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 157
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "trait_target" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 159
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "method_class" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 165
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "method_name" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 167
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "method_formula" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 169
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "model_variable_unit" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 171
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "scale_type" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 173
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "trait_name" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 155
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "trait_entity" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 157
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "trait_target" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 159
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "method_class" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 165
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "method_name" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 167
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "method_formula" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 169
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "model_variable_unit" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 171
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "scale_type" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 173
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "trait_name" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 155
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "trait_entity" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 157
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "trait_target" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 159
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "method_class" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 165
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "method_name" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 167
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "method_formula" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 169
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "model_variable_unit" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 171
ERROR - 2023-01-30 08:18:45 --> Severity: Warning --> Undefined array key "scale_type" C:\wamp64\www\AEGIS\application\views\variable_model\consultation.php 173
ERROR - 2023-01-30 08:23:35 --> Severity: error --> Exception: Class "PhpOffice\PhpSpreadsheet\Reader\Xlsx" not found C:\wamp64\www\AEGIS\application\controllers\Variables.php 772
ERROR - 2023-01-30 07:32:02 --> 404 Page Not Found: Assets/images
ERROR - 2023-01-30 08:34:30 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:34:30 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:34:30 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:34:30 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:34:30 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:34:30 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:34:30 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:34:30 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:34:30 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:34:30 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:34:30 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:34:30 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:34:30 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:34:30 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:34:30 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:34:30 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:34:30 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:34:30 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:34:30 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:34:30 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:35:12 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:35:12 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:35:12 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:35:12 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:35:12 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:35:12 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:35:12 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:35:12 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:35:12 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:35:12 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:35:12 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:35:12 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:35:12 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:35:12 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:35:12 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:35:12 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:35:12 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:35:12 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:35:12 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:35:12 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:35:22 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:35:22 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:35:22 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:35:22 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:35:22 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:35:22 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:35:22 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:35:22 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:35:22 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:35:22 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:35:22 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:35:22 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:35:22 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:35:22 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:35:22 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:35:22 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:35:22 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:35:22 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:35:22 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 08:35:22 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 10:02:53 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 10:02:53 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 10:02:53 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 10:02:53 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 10:02:53 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 10:02:53 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 10:02:53 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 10:02:53 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 10:02:53 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 10:02:53 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 10:02:53 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 10:02:53 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 10:02:53 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 10:02:53 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 10:02:53 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 10:02:53 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 10:02:53 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 10:02:53 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 10:02:53 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 10:02:53 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 10:02:54 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 10:02:54 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 10:02:54 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 10:02:54 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 10:02:54 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 10:02:54 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 10:02:54 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 10:02:54 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 10:02:54 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 10:02:54 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 10:02:54 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 10:02:54 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 10:02:54 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 10:02:54 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 10:02:54 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 10:02:54 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 10:02:54 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 10:02:55 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 10:02:55 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 10:02:55 --> Severity: Warning --> Undefined variable $accession_code C:\wamp64\www\AEGIS\application\views\accession\accessions.php 62
ERROR - 2023-01-30 10:06:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Shared\String.php:529) C:\wamp64\www\AEGIS\system\core\Common.php 570
ERROR - 2023-01-30 10:06:05 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Shared\String.php 529
ERROR - 2023-01-30 10:06:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Shared\String.php:529) C:\wamp64\www\AEGIS\system\core\Common.php 570
ERROR - 2023-01-30 10:06:45 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Shared\String.php 529
ERROR - 2023-01-30 10:15:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Shared\String.php:529) C:\wamp64\www\AEGIS\system\core\Common.php 570
ERROR - 2023-01-30 10:15:48 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Shared\String.php 529
ERROR - 2023-01-30 10:17:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Shared\String.php:529) C:\wamp64\www\AEGIS\system\core\Common.php 570
ERROR - 2023-01-30 10:17:24 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Shared\String.php 529
ERROR - 2023-01-30 10:20:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Shared\String.php:529) C:\wamp64\www\AEGIS\system\core\Common.php 570
ERROR - 2023-01-30 10:20:22 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Shared\String.php 529
ERROR - 2023-01-30 10:22:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Shared\String.php:529) C:\wamp64\www\AEGIS\system\core\Common.php 570
ERROR - 2023-01-30 10:22:28 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Shared\String.php 529
ERROR - 2023-01-30 10:27:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Shared\String.php:529) C:\wamp64\www\AEGIS\system\core\Common.php 570
ERROR - 2023-01-30 10:27:28 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Shared\String.php 529
ERROR - 2023-01-30 10:28:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Shared\String.php:529) C:\wamp64\www\AEGIS\system\core\Common.php 570
ERROR - 2023-01-30 10:28:18 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Shared\String.php 529
ERROR - 2023-01-30 10:36:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Shared\String.php:529) C:\wamp64\www\AEGIS\system\core\Common.php 570
ERROR - 2023-01-30 10:36:30 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Shared\String.php 529
ERROR - 2023-01-30 10:37:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Shared\String.php:529) C:\wamp64\www\AEGIS\system\core\Common.php 570
ERROR - 2023-01-30 10:37:16 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Shared\String.php 529
ERROR - 2023-01-30 10:37:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Shared\String.php:529) C:\wamp64\www\AEGIS\system\core\Common.php 570
ERROR - 2023-01-30 10:37:31 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Shared\String.php 529
ERROR - 2023-01-30 10:39:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Shared\String.php:529) C:\wamp64\www\AEGIS\system\core\Common.php 570
ERROR - 2023-01-30 10:39:47 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Shared\String.php 529
ERROR - 2023-01-30 10:46:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Shared\String.php:529) C:\wamp64\www\AEGIS\system\core\Common.php 570
ERROR - 2023-01-30 10:46:29 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Shared\String.php 529
ERROR - 2023-01-30 11:00:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Shared\String.php:529) C:\wamp64\www\AEGIS\system\core\Common.php 570
ERROR - 2023-01-30 11:00:07 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Shared\String.php 529
ERROR - 2023-01-30 11:01:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Shared\String.php:529) C:\wamp64\www\AEGIS\system\core\Common.php 570
ERROR - 2023-01-30 11:01:48 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Shared\String.php 529
ERROR - 2023-01-30 11:11:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Shared\String.php:536) C:\wamp64\www\AEGIS\system\core\Common.php 570
ERROR - 2023-01-30 11:11:40 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Shared\String.php 536
ERROR - 2023-01-30 11:11:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Shared\String.php:536) C:\wamp64\www\AEGIS\system\core\Common.php 570
ERROR - 2023-01-30 11:11:42 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Shared\String.php 536
ERROR - 2023-01-30 11:13:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Shared\String.php:537) C:\wamp64\www\AEGIS\system\core\Common.php 570
ERROR - 2023-01-30 11:13:30 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Shared\String.php 537
ERROR - 2023-01-30 11:14:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Calculation.php:2186) C:\wamp64\www\AEGIS\system\core\Common.php 570
ERROR - 2023-01-30 11:14:27 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Calculation.php 2186
ERROR - 2023-01-30 11:17:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Calculation.php:2186) C:\wamp64\www\AEGIS\system\core\Common.php 570
ERROR - 2023-01-30 11:17:45 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Calculation.php 2186
ERROR - 2023-01-30 11:17:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Calculation.php:2186) C:\wamp64\www\AEGIS\system\core\Common.php 570
ERROR - 2023-01-30 11:17:55 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Calculation.php 2186
ERROR - 2023-01-30 11:18:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Calculation.php:2294) C:\wamp64\www\AEGIS\system\core\Common.php 570
ERROR - 2023-01-30 11:18:28 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Calculation.php 2294
ERROR - 2023-01-30 11:19:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Calculation.php:2372) C:\wamp64\www\AEGIS\system\core\Common.php 570
ERROR - 2023-01-30 11:19:25 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Calculation.php 2372
ERROR - 2023-01-30 11:22:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Calculation.php:2383) C:\wamp64\www\AEGIS\system\core\Common.php 570
ERROR - 2023-01-30 11:22:10 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Calculation.php 2383
ERROR - 2023-01-30 11:22:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Calculation.php:2632) C:\wamp64\www\AEGIS\system\core\Common.php 570
ERROR - 2023-01-30 11:22:43 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Calculation.php 2632
ERROR - 2023-01-30 11:23:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Calculation.php:2761) C:\wamp64\www\AEGIS\system\core\Common.php 570
ERROR - 2023-01-30 11:23:11 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Calculation.php 2761
ERROR - 2023-01-30 11:24:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Calculation.php:2763) C:\wamp64\www\AEGIS\system\core\Common.php 570
ERROR - 2023-01-30 11:24:01 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Calculation.php 2763
ERROR - 2023-01-30 11:24:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Calculation.php:2764) C:\wamp64\www\AEGIS\system\core\Common.php 570
ERROR - 2023-01-30 11:24:39 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Calculation.php 2764
ERROR - 2023-01-30 11:25:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Calculation.php:3039) C:\wamp64\www\AEGIS\system\core\Common.php 570
ERROR - 2023-01-30 11:25:20 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Calculation.php 3039
ERROR - 2023-01-30 11:26:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Calculation.php:3459) C:\wamp64\www\AEGIS\system\core\Common.php 570
ERROR - 2023-01-30 11:26:43 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Calculation.php 3459
ERROR - 2023-01-30 11:28:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Calculation.php:3501) C:\wamp64\www\AEGIS\system\core\Common.php 570
ERROR - 2023-01-30 11:28:24 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Calculation.php 3501
ERROR - 2023-01-30 11:28:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Calculation.php:3505) C:\wamp64\www\AEGIS\system\core\Common.php 570
ERROR - 2023-01-30 11:28:59 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Calculation.php 3505
ERROR - 2023-01-30 11:30:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Calculation.php:3558) C:\wamp64\www\AEGIS\system\core\Common.php 570
ERROR - 2023-01-30 11:30:02 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Calculation.php 3558
ERROR - 2023-01-30 11:30:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Worksheet.php:1480) C:\wamp64\www\AEGIS\system\core\Common.php 570
ERROR - 2023-01-30 11:30:40 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\wamp64\www\AEGIS\application\third_party\PHPExcel\Worksheet\AutoFilter.php 729
