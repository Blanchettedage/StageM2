<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-02-14 04:37:01 --> 404 Page Not Found: Assets/images
ERROR - 2023-02-14 04:57:18 --> 404 Page Not Found: Assets/images
ERROR - 2023-02-14 05:02:10 --> 404 Page Not Found: Assets/images
ERROR - 2023-02-14 05:20:35 --> 404 Page Not Found: Assets/images
ERROR - 2023-02-14 05:25:33 --> 404 Page Not Found: Assets/images
ERROR - 2023-02-14 05:30:04 --> 404 Page Not Found: Assets/images
ERROR - 2023-02-14 06:30:53 --> Severity: Warning --> pg_query(): Query failed: ERREUR:  la valeur d'une clé dupliquée rompt la contrainte unique « bff_trial_pkey »
DETAIL:  La clé « (trial_code)=(P12_2017_2018) » existe déjà. C:\wamp64\www\AEGIS\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2023-02-14 06:30:53 --> Query error: ERREUR:  la valeur d'une clé dupliquée rompt la contrainte unique « bff_trial_pkey »
DETAIL:  La clé « (trial_code)=(P12_2017_2018) » existe déjà. - Invalid query: INSERT INTO "trial" ("trial_code", "site_code", "trial_description", "starting_date", "ending_date", "commentary", "controlled_environment") VALUES ('P12_2017_2018', NULL, NULL, '2017-01-01', '2018-01-01', NULL, 'f')
ERROR - 2023-02-14 05:31:40 --> 404 Page Not Found: Assets/images
ERROR - 2023-02-14 05:35:24 --> 404 Page Not Found: Assets/images
ERROR - 2023-02-14 05:43:07 --> 404 Page Not Found: Assets/images
ERROR - 2023-02-14 06:45:35 --> Severity: Warning --> pg_query(): Query failed: ERREUR:  la valeur d'une clé dupliquée rompt la contrainte unique « bff_trial_pkey »
DETAIL:  La clé « (trial_code)=(P41_2015_2016) » existe déjà. C:\wamp64\www\AEGIS\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2023-02-14 06:45:35 --> Query error: ERREUR:  la valeur d'une clé dupliquée rompt la contrainte unique « bff_trial_pkey »
DETAIL:  La clé « (trial_code)=(P41_2015_2016) » existe déjà. - Invalid query: INSERT INTO "trial" ("trial_code", "site_code", "trial_description", "starting_date", "ending_date", "commentary", "controlled_environment") VALUES ('P41_2015_2016', NULL, NULL, '2015-01-01', '2016-01-01', NULL, 'f')
ERROR - 2023-02-14 06:46:38 --> Severity: Warning --> pg_query(): Query failed: ERREUR:  la valeur d'une clé dupliquée rompt la contrainte unique « bff_trial_pkey »
DETAIL:  La clé « (trial_code)=(P41_2016_2017) » existe déjà. C:\wamp64\www\AEGIS\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2023-02-14 06:46:38 --> Query error: ERREUR:  la valeur d'une clé dupliquée rompt la contrainte unique « bff_trial_pkey »
DETAIL:  La clé « (trial_code)=(P41_2016_2017) » existe déjà. - Invalid query: INSERT INTO "trial" ("trial_code", "site_code", "trial_description", "starting_date", "ending_date", "commentary", "controlled_environment") VALUES ('P41_2016_2017', NULL, NULL, '2016-01-01', '2017-01-01', NULL, 'f')
ERROR - 2023-02-14 08:51:22 --> Le chemin de destination semble invalide.
