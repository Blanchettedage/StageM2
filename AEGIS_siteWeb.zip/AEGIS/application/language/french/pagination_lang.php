<?php
/**
 *  TRADUCTION FRANACAISE DE LA PAGINATION DE CODE-IGNITER
 *  
 *  @author Medhi Boulnemour <boulnemour.medhi@live.fr>
 */
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['pagination_first_link'] = '&lsaquo; Premier';
$lang['pagination_next_link'] = '&gt;';
$lang['pagination_prev_link'] = '&lt;';
$lang['pagination_last_link'] = 'Dernier &rsaquo;';
