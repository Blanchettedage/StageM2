<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Saisie_variable_model extends MY_Model
{
    public function __construct()
    {
        parent::__construct();
        $this->table = 'all_variable';
    }

    public function get_all_variable(){
        $query = $this->db->distinct()->select('*')
        ->from($this->table)
        ->get()
        ->result_array();
        return $query;
    }

    public function get_valid_variable(){
        $query = $this->db->distinct()->select('*')
        ->from($this->table)
        ->where('common_code is not null')
        ->get()
        ->result_array();
        return $query;
    }

    public function get_invalid_variable(){
        $query = $this->db->distinct()->select('*')
        ->from($this->table)
        ->where('common_code is null')
        ->order_by("entry_date", "desc")
        ->get()
        ->result_array();
        return $query;
    }

    public function exist_variable($code){ //  si vrai le code existe !!
        $query = $this->db->distinct()->select('*')
        ->from($this->table)
        ->where('variable_code',$code)
        ->get()
        ->result_array();
        
        //return $query;
        if (count($query)>0) {
            return true;
        }else return false;

    }
    //========================================CSD=======================================================
    public function getDistinctClassValid(){
        $query = $this->db->distinct()->select('class')->from($this->table)
        ->where('common_code is not null')
        ->order_by("class", "asc")
        ->get()
        ->result_array();

        return $query;
    }

    public function getDistinctSubclassValid(){
        $query = $this->db->distinct()->select('subclass')->from($this->table)
        ->where('common_code is not null')
        ->order_by("subclass", "asc")
        ->get()
        ->result_array();

        return $query;
    }

    public function getDistinctDomainValid(){
        $query = $this->db->distinct()->select('domain')->from($this->table)
        ->where('common_code is not null')
        ->order_by("domain", "asc")
        ->get()
        ->result_array();

        return $query;
    }

    public function getDistinctSubclassofClass($class){// les sous classe des variables valides
        $query = $this->db->distinct()->select('subclass')->from($this->table)
        ->where('common_code is not null')
        ->where('class',$class)
        ->order_by("subclass", "asc")
        ->get()
        ->result_array();

        return $query;
        
    }

    public function getDistincDomainValidOfSubclass($subclass){
        $query =  $this->db->distinct()->select('domain')->from($this->table)
        ->where('common_code is not null')
        ->where('subclass',$subclass)
        ->order_by("domain", "asc")
        ->get()
        ->result_array();

        // if (count($query) > 0) {
        //     return $query;
        // }else{
        //     $query2 = $this->db->distinct()->select('domain')->from($this->table)
        //         ->where('common_code is not null')
        //         ->order_by("domain", "asc")
        //         ->get()
        //         ->result_array();
        //     return $query2;
        // }
        return $query;
    }

    //Trait

    public function get_all_traits_valide(){
        $query = $this->db->distinct()->select('trait_code,trait_name')
        ->from($this->table)
        ->where('common_code is not null ')
        ->get()
        ->result_array();
        return $query;
        
    }

    //affiche tous les traits (même les traits non affilié aux variables)
    public function get_all_traits(){
        $query = $this->db->distinct()->select('*')
        ->from('trait')
        ->order_by('trait_name','asc')
        ->get()
        ->result_array();
        return $query;
    }

    public function trait_code_exist($code){
        $query = $this->db->distinct()->select('*')
        ->from('trait')
        ->where('trait_code',$code)
        ->get()
        ->result_array();
        
        if (count($query)>0) {
            return true;
        }else return false;
        
    }

    public function entity_code_exist($code){
        $query = $this->db->distinct()->select('*')
        ->from('entity')
        ->where('entity_code',$code)
        ->get()
        ->result_array();
        
        if (count($query)>0) {
            return true;
        }else return false;
    }

    public function target_name_exist($code){
        $query = $this->db->distinct()->select('*')
        ->from('all_variable')
        ->where('trait_target',$code)
        ->get()
        ->result_array();
        
        if (count($query)>0) {
            return true;
        }else return false;
    }

   

    
    


    /* La lecture du code la variable commune se fait grâce a un booléen "common_variable" :
        Si Vrai : Le variable_code est le code de la variable commune
        Si Faux : Le champ common_variable code est renseigné avec un code variable commune.
    */

    // public function get_common_var_from_trait($trait_code){ 
    //     $query = $this->db->distinct()->select('common_code')
    //     ->from($this->table)
    //     ->where('trait_code',$trait_code)
    //     ->get()
    //     ->result_array();
    //     return $query;
    // }


     //Method

    public function method_exist($code){ //si la méthod existe on envoie faux sinon on envoie vrai
        $query = $this->db->distinct()->select('*')
        ->from('method')
        ->where('method_code',$code)
        ->get()
        ->result_array();
        
        if (count($query)>0) {
            return true;
        }else return false;
    }

    public function get_method_from_trait_valide($trait_code){
        $query = $this->db->distinct()->select('method_name,method_code')
        ->from($this->table)
        ->where('trait_code',$trait_code)
        ->where('common_code is not null')
        ->order_by('method_name','asc')
        ->get()
        ->result_array();
        return $query;
    }

    public function get_all_methods(){
        $query = $this->db->distinct()->select('*')
        ->from('method')
        ->order_by('method_name','asc')
        ->get()
        ->result_array();
        return $query;
    }

    public function get_scale_from_trait_method_valide($trait,$method){
        $query = $this->db->distinct()->select('scale_code,scale_name')
        ->from($this->table)
        ->where('trait_code',$trait)
        ->where('method_code',$method)
        ->where('common_code is not null')
        ->order_by('scale_name','asc')
        ->get()
        ->result_array();
        return $query;
    }

    public function get_all_scales(){
        $query = $this->db->distinct()->select('*')
        ->from('scale')
        ->order_by('scale_name','asc')
        ->get()
        ->result_array();
        return $query;
    }

    public function scale_exist($code){ //si la méthod existe  on envoie vrai
        $query = $this->db->distinct()->select('*')
        ->from('scale')
        ->where('scale_code',$code)
        ->get()
        ->result_array();
        
        if (count($query)>0) {
            return true;
        }else return false;
    }

    public function get_all_entity(){
        $query = $this->db->distinct()->select('*')
        ->from('entity')
        ->order_by('entity_name','asc')
        ->get()
        ->result_array();
        return $query;
    }

    public function get_all_target(){
        $query = $this->db->distinct()->select('trait_target')
        ->from($this->table)
        ->order_by('trait_target','asc')
        ->get()
        ->result_array();
        return $query;
    }

    public function getVarFromCSD($C,$S,$D){ // avoir un ensemble de variable correspondant à une union de class, subclass et domaine
        $CSD = "class = '".$C."' and subclass = '".$S."' and domain = '".$D."'";//array('class'=>$C,'subclass'=>$S,'domain'=>$D);
        $CS = "class = '".$C."' and subclass = '".$S."'";
        $CD = "class = '".$C."' and domain = '".$D."'";
        $SD ="subclass = '".$S."' and domain = '".$D."'";
        $query = $this->db->select('*')->from('all_variable')
        ->where($CSD)
        ->or_where($CS)
        ->or_where($CD)
        ->or_where($SD)
        // ->or_where('class',$C)
        // ->or_where('subclass',$S)
        // ->or_where('domain',$D)
        ->get()
        ->result_array();
        if (count($query)==0) { // Si les conjonction renvoie faux on envoie les disjonctions
            $query = $this->db->select('*')->from('all_variable')
            ->or_where('class',$C)
            ->or_where('subclass',$S)
            ->or_where('domain',$D)
            ->get()
            ->result_array();
        }
        return $query;
    }
    
    public function getVarFromCSD1($select,$c,$s,$d){ // avoir un ensemble de variable correspondant à une union de class, subclass et domaine
        $class  =   $this->db->distinct()->select($select)->from('all_variable')
                    ->where('class',$c)
                    ->get()
                    ->result_array();
        $subclass = $this->db->distinct()->select($select)->from('all_variable')
                    ->where('subclass',$s)
                    ->get()
                    ->result_array();
        $domain =   $this->db->distinct()->select($select)->from('all_variable')
                    ->where('domain',$d)
                    ->get()
                    ->result_array();

        if (count($class)>0) {
            if(count($subclass)>0){
                if (count($domain)>0) { //cas où tous les elements sont reconnu //CSD
                    return $this->db->distinct()->select($select)->from('all_variable')
                            ->where('class',$c)
                            ->where('subclass',$s)
                            ->where('domain',$d)
                            ->get()
                            ->result_array();

                }else{// cas où le domain n'est pas reconnu //CS
                    return $this->db->distinct()->select($select)->from('all_variable')
                            ->where('class',$c)
                            ->where('subclass',$s)
                            ->get()
                            ->result_array();
                }

            }else{ // cas où la sous classe n'est pas reconnu
                if (count($domain)>0) { //cas où tous les elements sont reconnu //CD
                    return $this->db->distinct()->select($select)->from('all_variable')
                            ->where('class',$c)
                            ->where('domain',$d)
                            ->get()
                            ->result_array();
                }else{// cas où le domain n'est pas reconnu //C
                    return $this->db->distinct()->select($select)->from('all_variable')
                            ->where('class',$c)
                            ->get()
                            ->result_array();
                }
            }
        }else { // cas où la classe est null
            if(count($subclass)>0){
                if (count($domain)>0) { //cas où tous les elements sont reconnu //SD
                    return $this->db->distinct()->select($select)->from('all_variable')
                            ->where('subclass',$s)
                            ->where('domain',$d)
                            ->get()
                            ->result_array();
                }else{// cas où le domain n'est pas reconnu //S
                    return $this->db->distinct()->select($select)->from('all_variable')
                            ->where('subclass',$s)
                            ->get()
                            ->result_array();
                }
            }else{ // cas où la sous classe n'est pas reconnu
                if (count($domain)>0) { //cas où tous les elements sont reconnu //D
                    return $this->db->distinct()->select($select)->from('all_variable')
                            ->where('domain',$d)
                            ->get()
                            ->result_array();
                }else{// cas où le domain n'est pas reconnu //
                    return array();
                }
            }
        }
    }

    public function getVarFromCSD2($select,$c,$s,$d){ // avoir un ensemble de variable correspondant à une union de class, subclass et domaine
        $class  =   $this->db->distinct()->select($select)->from('all_variable')
                    ->where('class',$c)
                    ->where('common_code is not null')
                    ->get()
                    ->result_array();
        $subclass = $this->db->distinct()->select($select)->from('all_variable')
                    ->where('subclass',$s)
                    ->where('common_code is not null')
                    ->get()
                    ->result_array();
        $domain =   $this->db->distinct()->select($select)->from('all_variable')
                    ->where('domain',$d)
                    ->where('common_code is not null')
                    ->get()
                    ->result_array();

        if (count($class)>0) {
            if(count($subclass)>0){
                if (count($domain)>0) { //cas où tous les elements sont reconnu //CSD
                    return $this->db->distinct()->select($select)->from('all_variable')
                            ->where('class',$c)
                            ->where('subclass',$s)
                            ->where('domain',$d)
                            ->where('common_code is not null')
                            ->get()
                            ->result_array();

                }else{// cas où le domain n'est pas reconnu //CS
                    return $this->db->distinct()->select($select)->from('all_variable')
                            ->where('class',$c)
                            ->where('subclass',$s)
                            ->where('common_code is not null')
                            ->get()
                            ->result_array();
                }

            }else{ // cas où la sous classe n'est pas reconnu
            // cas où le domain n'est pas reconnu //C
                return $this->db->distinct()->select($select)->from('all_variable')
                        ->where('class',$c)
                        ->where('common_code is not null')
                        ->get()
                        ->result_array();
                
            }
        }
    }

    function create_variable($values){
        $this->db->insert('variable',array("variable_code"=>'test'));
        return true;
    }

    function updateVariable($code){
        
    }

}