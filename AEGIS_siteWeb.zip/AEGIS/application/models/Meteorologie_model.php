<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Meteorologie_model extends MY_Model {
	
	public function __construct()
	{
		parent::__construct();
		$this->table = 'meteorologie';
	}
  
	/**
	* Retourne vrai si l'meteorologie existe
	*/
	public function exist($str)
    {
        if ($this->find(array('meteorologie_name' => $str))) return TRUE;
        else return FALSE;
    }
	

    /**
     * Créé un nouvel enregistrement avec les valeurs passées en paramètre
     **/
    public function create($values)
    {
        if ($this->db->set($values)->insert($this->table)) return TRUE;
        return null;
    }
	
	/**
	* Importe les données d meteorologies depuis un tableau de données bidimensionnel
	*/
	public function import($data) {
		
		$this->db->trans_start();
		foreach ($data as $row) {
			$this->create(array(
				'meteorologie_name' => $row['meteorologie_name'],
				'class' => $row['meteorologie_class'],
				'features' => $row['meteorologie_feature']
				));
		}

		$this->db->trans_complete();
		return $this->db->trans_status();
	}
	
}
