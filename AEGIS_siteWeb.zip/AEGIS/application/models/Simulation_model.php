<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Simulation_model extends MY_Model
{
	
	protected $table = 'data_simulation';
	
	
    public function __construct()
    {
        parent::__construct();
        $this->table = 'data_simulation';
    }

    public function getAllProjects(){
        $query = $this->db->distinct()->select('project_code,project_name')
        ->from($this->table)
        ->order_by("project_name", "asc")
        ->get()
        ->result_array();
        return $query;
    }

    public function getTrialsFromProject($project){
        $query = $this->db->distinct()->select('trial_code, trial_description')
        ->from($this->table)
        ->where('project_code','ICSM')
        ->order_by("trial_code", "asc")
        ->get()
        ->result_array();
        return $query;
    }

    
    public function getDateFromTrial($code){
        $query = $this->db->distinct()->select('starting_date')
        ->from($this->table)
        ->where('trial_code',$code)
        ->get()
        ->result_array();
        return $query;
    }

    public function getdatawhithfilter($p,$t,$d){ //Erreur lors de l'appel (Trop d'élément à chargé ??)
        $query = $this->db->select('*')
        ->from('data_simulation')
        ->get()
        ->result_array();
        return $query;
    }

}
