<?php
defined('BASEPATH') or exit('No direct script access allowed');

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class Variables extends MY_Controller
{

	public function __construct()
	{
		parent::__construct();
		if (!$this->session->userdata('connected')) {
			set_status_header(401);
			show_error("Vous devez être connecté pour accéder à cette page. <a href=\"" . site_url('welcome/login') . "\">Connexion</a>", 401);
			return;
		}

		$this->load->helper(array('form', 'url'));
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<div class="alert alert-danger"><span class="glyphicon glyphicon-warning-sign"></span>', '</div>');
		$this->load->model('Variable_model');
		$this->load->model('ModelVariable_model');
		$this->load->model('saisie_variable_model');

	}


	/**
	 * Ajoute a la variable de session 'array_variable' la variable passée en post
	 * Si la variable de session n'existe pas, on la créer
	 */
	public function add_var_in_session()
	{
		if (!$this->input->is_ajax_request()) {
			show_404();
		} else {
			$array_var = array();
			if ($this->session->userdata('array_variable') != null) {
				/*$this->session->userdata('array_variable', array());*/
				$array_var = $this->session->userdata('array_variable');
				// print_r("création ");
			}
			$var_name = $this->input->post('var_name');
			//print_r("add : ".$var_name);
			$int_return = -1;
			if (in_array($var_name, $array_var)) {
				$int_return = 2;
			} else {
				array_push($array_var, $var_name);
				$int_return = 1;
			}

			$this->session->set_userdata('array_variable', $array_var);

			echo json_encode($int_return);
		}
	}
	/**
	 * Enlebe a la variable de session 'array_variable' la variable passée en post
	 */
	public function remove_var_in_session()
	{
		if (!$this->input->is_ajax_request()) {
			show_404();
		} else {
			$var_name = $this->input->post('var_name');
			$init_length = count($this->session->userdata('array_variable'));
			$key = array_search($var_name, $this->session->userdata('array_variable'));
			$arrayTemp = $this->session->userdata('array_variable');
			array_splice($arrayTemp, $key, 1);

			$this->session->set_userdata('array_variable', $arrayTemp);

			$int_return = -1;
			if ($init_length = count($this->session->userdata('array_variable')) + 1) {
				$int_return = 1;
			}
			echo json_encode($int_return);
		}
	}


	/**
	 * Affiche la page principal permettant d'accedé au différentes fonctionnalités du dictionnaire des variables
	 */
	public function index()
	{
		// Titre de la page
		$page['title'] = 'Dictionnaire des variables';
		$page['subtitle'] = '';

		$data['empty'] = "";

		$scripts = array('bootstrap-select-ajax-plugin');
		$this->view('variable/accueil', $page['title'], $page['subtitle'], $data, $scripts);
	}

	/**
	 * Affiche la page de consultation du panier (variable + model)
	 */
	public function display_cart()
	{

		// Titre de la page
		$page['title'] = 'Panier';
		$page['subtitle'] = 'Consultation';
		$array_data_var = array();
		$array_data_model = array();

		// print_r($this->session->userdata('array_variable'));
		// print_r($this->session->userdata('array_model'));





		/**
		 * Gère les données modèles et variables
		 */
		if ($this->session->userdata('array_model') != null && count($this->session->userdata('array_model')) > 0) {
			foreach ($this->session->userdata('array_model') as $key => $variable) {

				$data_var = $this->ModelVariable_model->selectVarModel($variable);

				array_push($array_data_model, $data_var);
			}
		}


		if ($this->session->userdata('array_variable') != null && count($this->session->userdata('array_variable')) > 0) {
			foreach ($this->session->userdata('array_variable') as $key => $variable) {

				$data_var = $this->Variable_model->get_var_trait_entity_method_scale($variable);
				array_push($array_data_var, $data_var);
			}
		}

		$data["data_mod"] = $array_data_model;
		$data["data_var"] = $array_data_var;
		//$data["data_var"] = $array_data;
		$scripts = array('bootstrap-select-ajax-plugin', 'variable_session_consultation'/* , 'variableModel_consultation' */);
		$this->view('cart/cart_var', $page['title'], $page['subtitle'], $data, $scripts);
	}

	/**
	 * Permet de générer un fichier Excel avec comme colonnes l'ensemble des variables dans le panier
	 */
	public function create_excel_file()
	{
		if ($this->session->userdata('array_variable') != null && count($this->session->userdata('array_variable')) > 0) {
			$this->load->library('excel');
			$this->load->library('table');

			$array_var = $this->session->userdata('array_variable');

			$object = new PHPExcel();
			$object->setActiveSheetIndex(0);

			//set les nom des colonnes avec les noms des variabeles
			$column = 0;
			foreach ($array_var as $key => $var_name) {
				$object->getActiveSheet()->setCellValueByColumnAndRow($column, 1, $var_name);
				$column++;
			}

			$object_writer = PHPExcel_IOFactory::createWriter($object, 'Excel5');
			header('Content-Type: application/vnd.ms-excel');
			header('Content-Disposition: attachment;filename="variables.xls"');
			$object_writer->save('php://output');
		} else {
			redirect('variables/display_cart', 'location');
		}
	}

	/**
	 * affiche la page de consultation des variables
	 * Si aucun paramètre alors on affiche la page générale qui présente toutes les variables (dictionnaire des variables)
	 * Si il y a un paramètre alors on affiche la page détaillé de la variables passée en paramètre
	 */
	public function consultation($variable_code = '')
	{
		if ($variable_code == null || $variable_code == '') {
			/**
			 * affiche la page de consultation de toutes les variables "dictionnaire des variables"
			 */
			// Titre de la page
			$page['title'] = 'Catalogue des variables';
			$page['subtitle'] = '';


			$data['distinct_class'] = $this->Variable_model->select_distinct_class_valid();
			$data['distinct_subclass'] = $this->Variable_model->select_distinct_subclass_valid();
			$data['distinct_domain'] = $this->Variable_model->select_distinct_domain_valid();
			$data['class_subclass_domain'] = $this->Variable_model->select_distinct_class_subclass_domain();

			//$data['varesult'] =$this->Variable_model->get_all_from_varesult();
			// $data['varesult'] = $this->Variable_model->getAllVar1();
			$data['varesult'] = $this->Variable_model->getCommonVar();
			$scripts = array('bootstrap-select-ajax-plugin', 'variable_consultation');
			$this->view('variable/consultation', $page['title'], $page['subtitle'], $data, $scripts);
		} else {
			/**
			 * affiche la page de consultation détaillée d'une variable passée en paramètre
			 */


			//decodage du code variable passé en param problème avec les signes '%, /'
			$uri_seg = $this->uri->uri_to_assoc(4);
			$real_variable_code = urldecode($variable_code);
			foreach ($uri_seg as $key => $para) {
				$real_variable_code .= "/" . urldecode($key);
				if ($para != null && $para != '') {
					$real_variable_code .= "/" . urldecode($para);
				}
			}

			// Titre de la page
			$page['title'] = 'consultation des variables';
			$page['subtitle'] = $real_variable_code;

			$data['variable_code'] = $variable_code;
			$data['real_variable_code'] = $real_variable_code;

			$data['variable_varesult'] = $this->Variable_model->return_var_from_varesult($real_variable_code);
			/*if ($data['variable_varesult'] == null) {

	        }else{

	        }*/
			$this->load->model(array('Trait_model', 'Method_model', 'Scale_model', 'Entity_model'));

			$data['info_without_onto'] = $this->Variable_model->get_var_trait_entity_method_scale($real_variable_code);
			$data['var_onto'] = $this->Variable_model->get_ontology($real_variable_code);
			$data['trait_onto'] = $this->Trait_model->get_ontology($data['info_without_onto']['trait_code']);
			$data['entity_onto'] = $this->Entity_model->get_ontology($data['info_without_onto']['entity_code']);
			$data['method_onto'] = $this->Method_model->get_ontology($data['info_without_onto']['method_code']);
			$data['scale_onto'] = $this->Scale_model->get_ontology($data['info_without_onto']['scale_code']);


			$scripts = array('bootstrap-select-ajax-plugin', 'detail_consultation_variable');
			$this->view('variable/detail_consultation', $page['title'], $page['subtitle'], $data, $scripts);
		}
	}




	public function saisie(){
		// Titre de la page
		$page['title'] = 'Création de nouvelle variable';
		$page['subtitle'] = 'Formulaire de saisie de création d\'une variable';

		$this->load->model(array('Trait_model', 'Method_model', 'Scale_model', 'Entity_model','saisie_variable_model'));


		//--------------------------------------------------------------------------------------------------------------//
		//								   			Requête Variable Communes								    		//	
		//--------------------------------------------------------------------------------------------------------------//

		//Data variable input
		$data['distinctClass'] = $this->saisie_variable_model->getDistinctClassValid();
		$data['distinctSubclass'] = [];//$this->Variable_model->select_distinct_subclass();
		$data['distinctDomain'] = [];//$this->Variable_model->select_distinct_domain();
		
		//Envoie les traits de tous les variables 
		$data['all_traits'] = $this->saisie_variable_model->get_all_traits();
		$data['all_entity'] = $this->saisie_variable_model->get_all_entity();
		$data['all_target'] = $this->saisie_variable_model->get_all_target();
		$data['author'] = $this->session->userdata('username');

 
		//--------------------------------------------------------------------------------------------------------------//
		
		
		
		$data['method_classes'] = $this->Method_model->get_distinct_classes();
		$data['method_subclasses'] = $this->Method_model->get_distinct_subclasses();

		// Récupération des données du formulaire
		//$data['variable_code'] = $this->input->post('variable_code');
		// $data['trait_code'] = $this->input->post('trait_code');
		// $data['method_code'] = $this->input->post('method_code');
		// $data['scale_code'] = $this->input->post('scale_code');
		// $data['author'] = $this->session->userdata('username'); //$this->input->post('author');
		// $data['class'] = $this->input->post('class');
		// $data['subclass'] = $this->input->post('subclass');
		// $data['domain'] = $this->input->post('domain');

		$scripts = array('bootstrap-select-ajax-plugin', 'new_variable2');
		$messageErrors = array();

		// Règles de validation du formulaire
		// $this->form_validation->set_rules('variable_code', 'Code variable', 'required|trim|max_length[50]|xss_clean');
		// $this->form_validation->set_rules('trait_code', 'Code trait', 'trim|max_length[50]|xss_clean');
		// $this->form_validation->set_rules('method_code', 'Code méthode', 'trim|max_length[50]|xss_clean');
		// $this->form_validation->set_rules('scale_code', 'Code échelle/unité', 'trim|max_length[50]|xss_clean');
		// $this->form_validation->set_rules('author', 'Auteur', 'trim|max_length[100]|xss_clean');
		// $this->form_validation->set_rules('class', 'Classe', 'trim|max_length[255]|xss_clean');
		// $this->form_validation->set_rules('subclass', 'Sous classe', 'trim|max_length[255]|xss_clean');
		// $this->form_validation->set_rules('domain', 'Domaine', 'trim|max_length[255]|xss_clean');

		$this->load->library('session');

		// Test de validation du formulaire
		/* if ($this->form_validation->run()) {
			$this->load->helper('postgre');

			$data = nullify_array($data); // Remplace les chaines de caractères vide par la valeur NULL
			if (!($this->Variable_model->exist($data['variable_code']))) {
				if (!$this->Variable_model->create(
					array(
						'variable_code' => $data['variable_code'],
						'trait_code' => $data['trait_code'],
						'method_code' => $data['method_code'],
						'scale_code' => $data['scale_code'],
						'author' => $data['author'],
						'class' => $data['class'],
						'subclass' => $data['subclass'],
						'domain' => $data['domain']
					)
				)) {
					$this->session->set_flashdata('msg', 'Erreur lors de la création des données de Variable');
					$this->session->set_flashdata('msg_state', 'danger');
				} else {
					$this->session->set_flashdata('msg', 'La variable a été créée avec succés !');
					$this->session->set_flashdata('msg_state', 'success');
				}
			} else {
				$this->session->set_flashdata('msg', 'Une variable portant ce variable_code existe déjà');
				$this->session->set_flashdata('msg_state', 'danger');
			}
		} */
		// Affichage du formulaire de création de variables et retour des erreurs
		$this->view('variable/saisie_variable', $page['title'], $page['subtitle'], $data,  $scripts);
	}

	// function saisie new variable

	function get_author(){
		echo json_encode($this->session->userdata('username'));
	}


	function load_methods_valide(){ //On stocke la variable commune puis on charge les méthodes associé a la var commune.
		$ajaxData = array();
		$trait_code = json_decode($this->input->post('trait_code'));
		$ajaxData['methods'] = $this->saisie_variable_model->get_method_from_trait_valide($trait_code);
		echo json_encode($ajaxData);
	}

	function load_methods(){ //On stocke la variable commune puis on charge les méthodes associé a la var commune.
		echo json_encode($this->saisie_variable_model->get_all_methods());
	}


	function load_scales_valide(){//on affiche les unitées distinct 
		$ajaxData = array();
		$method_code = json_decode($this->input->post('method_code'));
		$trait_code = json_decode($this->input->post('trait_code'));
		$ajaxData['scales'] = $this->saisie_variable_model->get_scale_from_trait_method_valide($trait_code,$method_code);

		echo json_encode($ajaxData);
	}

	function load_scales(){
		echo json_encode($this->saisie_variable_model->get_all_scales());
	}


	function load_all_trait(){
		$ajaxData = array();
		$ajaxData['var'] = $this->saisie_variable_model->get_all_traits();
		echo json_encode($ajaxData);
	}

	function loadvarCSD(){ 
		$C = json_decode($this->input->post('class'));
		$S = json_decode($this->input->post('subclass'));
		$D = json_decode($this->input->post('domain'));
		$field = json_decode($this->input->post('field'));
		
		$ajaxData = array();
		$ajaxData['CSD'] = $this->saisie_variable_model->getVarFromCSD2($field,$C,$S,$D);
		//$ajaxData['CSD'] = $this->saisie_variable_model->getVarFromCSD($C,$S,$D);
		echo json_encode($ajaxData);
	}


	//Chargement des CSD
	function getDistinctClass() {
		$ajaxData = array();
		$ajaxData['class'] = $this->saisie_variable_model->getDistinctClassValid();
		echo json_encode($ajaxData);//$this->variable_model->select_distinct_class());
	}

	function getDistinctSubclass(){
		$ajaxData = array();
		$ajaxData['subclass'] = $this->saisie_variable_model->getDistinctSubclassValid();
		echo json_encode($ajaxData);//$this->variable_model->select_distinct_class());
	}

	function getDistinctSubclassfromClass(){
		$ajaxData = array();
		$class = json_decode($this->input->post('class'));
		$ajaxData['subclass'] = $this->saisie_variable_model->getDistinctSubclassofClass($class);
		echo json_encode($ajaxData);
	}

	function getDistinctDomain(){
		$ajaxData = array();
		$ajaxData['domain'] = $this->saisie_variable_model->getDistinctDomainValid();
		echo json_encode($ajaxData);//$this->variable_model->select_distinct_class());
	}

	function getDistinctDomainfromSubclass(){
		$ajaxData = array();
		$subclass = json_decode($this->input->post('subclass'));
		$ajaxData['domain'] = $this->saisie_variable_model->getDistincDomainValidOfSubclass($subclass);
		echo json_encode($ajaxData);
	}
	

	function exist_trait_code(){
		$trait = $this->input->post('trait_code');
		echo json_encode($this->saisie_variable_model-> trait_code_exist($trait));
		
	}

	function exist_entity_code(){
		$entity = $this->input->post('entity');
		echo json_encode($this->saisie_variable_model->entity_code_exist($entity));
	}

	function exist_target(){
		$target = $this->input->post('target_name');
		echo json_encode($this->saisie_variable_model->target_name_exist($target));
	}

	function exist_method(){
		$code = $this->input->post('method_code');
		echo json_encode($this->saisie_variable_model->method_exist($code));
	}

	function exist_scale(){
		$code = $this->input->post('scale_code');
		echo json_encode($this->saisie_variable_model->scale_exist($code));
	}

	function exist_var(){
		$code = $this->input->post('var_code');
		echo json_encode($this->saisie_variable_model->exist_variable($code));
	}

	function create_var(){
		$code = $this->input->post("var_code");
		$trait = $this->input->post("trait");
		$method = $this->input->post("method");
		$scale = $this->input->post("scale");
		$class = $this->input->post("class");
		$subclass = $this->input->post("subclass");
		$domain = $this->input->post("domain");
		$author = $this->input->post("author");

		
		
		$request = $this->Variable_model->create(array(
			"variable_code" => $code,
			"trait_code" => $trait,
			"method_code" => $method? $method : NULL,
			"scale_code" => $scale,
			"author" => $author,
			"class" => $class,
			"subclass" => $subclass,
			"domain" => $domain,
			"entry_date" => date('d/m/Y')
		));
		echo json_encode($request);

	}

	//===========================================================================================================================

	


	public function create()
	{
		// Titre de la page
		$page['title'] = 'Création de nouvelle variable';
		$page['subtitle'] = 'Formulaire de saisie de création d\'une variable';

		// Récupération des données du formulaire
		$data['variable_code'] = $this->input->post('variable_code');
		$data['trait_code'] = $this->input->post('trait_code');
		$data['method_code'] = $this->input->post('method_code');
		$data['scale_code'] = $this->input->post('scale_code');
		$data['author'] = $this->session->userdata('username');//$this->input->post('author');
		$data['class'] = $this->input->post('class');
		$data['subclass'] = $this->input->post('subclass');
		$data['domain'] = $this->input->post('domain');

		$scripts = array('bootstrap-select-ajax-plugin');
		$messageErrors = array();

		// Règles de validation du formulaire
		$this->form_validation->set_rules('variable_code', 'Code variable', 'required|trim|alpha_dash|max_length[50]|xss_clean');
		$this->form_validation->set_rules('trait_code', 'Code trait', 'trim|required|alpha_dash|max_length[50]|xss_clean');
		$this->form_validation->set_rules('method_code', 'Code méthode', 'trim|required|alpha_dash|max_length[50]|xss_clean');
		$this->form_validation->set_rules('scale_code', 'Code échelle/unité', 'trim|max_length[50]|xss_clean');
		$this->form_validation->set_rules('author', 'Auteur', 'trim|alpha_numeric_spaces|max_length[100]|xss_clean');
		$this->form_validation->set_rules('class', 'Classe', 'trim|alpha_numeric_spaces|max_length[255]|xss_clean');
		$this->form_validation->set_rules('subclass', 'Sous classe', 'trim|alpha_numeric_spaces|max_length[255]|xss_clean');
		$this->form_validation->set_rules('domain', 'Domaine', 'trim|alpha_numeric_spaces|max_length[255]|xss_clean');

		// Test de validation du formulaire
		if ($this->form_validation->run()) {
			$this->load->helper('postgre');

			$data = nullify_array($data); // Remplace les chaines de caractères vide par la valeur NULL
			if (!($this->Variable_model->exist($data['variable_code']))) {
				if (!$this->Variable_model->create(
					array(
						'variable_code' => $data['variable_code'],
						'trait_code' => $data['trait_code'],
						'method_code' => $data['method_code'],
						'scale_code' => $data['scale_code'],
						'author' => $data['author'],
						'class' => $data['class'],
						'subclass' => $data['subclass'],
						'domain' => $data['domain']
					)
				)) {
					$data['msg'] = "Erreur lors de la création des données de Variable";
					$this->view('error', $page['title'], $page['subtitle'], $data);
				} else {
					$data['msg'] = "La variable a été créée avec succés!";
					$this->view('success', $page['title'], $page['subtitle'], $data);
				}
			} else {
				$data['msg'] = "Une variable portant ce variable_code existe déjà";
				$this->view('error', $page['title'], $page['subtitle'], $data);
			}
		} else {
			// Affichage du formulaire de création de variables et retour des erreurs
			$this->view('variable/new_variable', $page['title'], $page['subtitle'], $data,  $scripts);
		}
	}

	/**
	 * Lien de téléchargement du formulaire d'importation des variables
	 */
	public function download_form()
	{
		$this->load->helper('download');
		$file_path = 'download_forms/Import_variable.xlsx'; //chemin absolu de mon fichier dans serveur
		force_download($file_path, NULL);
	}

	/**
	 * Appel de la vue import
	 */
	public function mains_page()
	{
		$page['title'] = "Importation de variables";
		$page['subtitle'] = "Formulaire d'importation des variables";
		$scripts = array('bootstrap-select-ajax-plugin');
		$this->view('variable/import', $page['title'], $page['subtitle'], $scripts);
	}

	/**
	 * Formulaire d'importation des variables
	 */
	public function import()
	{
		$page['title'] = "Importation des variables";
		$page['subtitle'] = "Formulaire d'importation des variables";

		$config['upload_path'] = UPLOAD_PATH; //Le chemin d'accès au répertoire où le téléchargement doit être placé.
		$config['allowed_types'] = 'xls|xlsx'; // Autres extensions de la librairie phpexcel xml|ods|slk|gnumeric|csv|htm|html
		$config['encrypt_name'] = TRUE;

		$this->load->library('excel');
		$this->load->library('table');
		$this->load->library('upload', $config);

		$scripts = array('bootstrap-select-ajax-plugin');

		$data = array();

		// if not successful, set the error message
		if (!$this->upload->do_upload('variable_file')) {
			$data['error'] = $this->upload->display_errors('<div class="alert alert-danger"><span class="glyphicon glyphicon-warning-sign"></span>', '</div>');
			$this->view('variable/import', $page['title'], $page['subtitle'], $data, $scripts);
		} else {
			try {
				$this->load->model(array('Entity_model', 'Target_model', 'Trait_model', 'Method_model', 'Scale_model'));

				$upload_data = $this->upload->data(); //return mon fichier de téléchargement

				PHPExcel_Settings::setZipClass(PHPExcel_Settings::PCLZIP);
				PHPExcel_Settings::setZipClass(PHPExcel_Settings::ZIPARCHIVE);
				$objPHPExcel = PHPExcel_IOFactory::load($upload_data['full_path']); //full_path est le chemin absolu vers le serveur y compris le nom de mon fichier excel

				// récupère tous les noms de feuilles du fichier
				$worksheetNames = $objPHPExcel->getSheetNames($upload_data['full_path']);
				$worksheetArray = array();

				foreach ($worksheetNames as $key => $sheetName) { //parcours de chaque feuille
					if ($sheetName != 'Lexicon') {
						//set the current active worksheet by name
						$objPHPExcel->setActiveSheetIndexByName($sheetName);
						// crée un tableau assoc avec le nom de la feuille en tant que clé et le tableau des contenus de la feuille comme valeur
						$worksheetArray[$sheetName] = $objPHPExcel->getActiveSheet();
					}
				}

				$nbreDeLignesVariable = $objPHPExcel->setActiveSheetIndex(0)->getHighestRow();
				$nbreDeLignesEntity = $objPHPExcel->setActiveSheetIndex(1)->getHighestRow();
				$nbreDeLignesTarget = $objPHPExcel->setActiveSheetIndex(2)->getHighestRow();
				$nbreDeLignesTrait = $objPHPExcel->setActiveSheetIndex(3)->getHighestRow();
				$nbreDeLignesMethod = $objPHPExcel->setActiveSheetIndex(4)->getHighestRow();
				$nbreDeLignesScale = $objPHPExcel->setActiveSheetIndex(5)->getHighestRow();

				//definition des tableaux contenant les colonnes de base des feuilles du fichier d'import
				$waiting_variable_header = array('variable_code', 'trait_code', 'method_code', 'scale_code', 'author', 'class', 'subclass', 'domain');
				$waiting_entity_header = array('entity_code', 'entity_name', 'entity_definition');
				$waiting_target_header = array('target_name');
				$waiting_trait_header = array('trait_code', 'trait_name', 'trait_description', 'trait_entity_code', 'trait_target_name', 'trait_author');
				$waiting_method_header = array('method_code', 'method_name', 'method_class', 'method_subclass', 'method_description', 'method_formula', 'method_reference', 'method_type', 'content_type', 'author');
				$waiting_scale_header = array('scale_code', 'scale_name', 'scale_type', 'scale_level');


				$data['lignesErrors'] = array();
				$data['messageErrors'] = array();

				if ($nbreDeLignesVariable > 1) {
					if ($nbreDeLignesScale > 1) {

						$tabResultCheckData['Scale'] = $this->format_worksheetdata($worksheetArray['Scale'], 'Scale', $waiting_scale_header);
						if (count($tabResultCheckData['Scale']['lignesErrors']) > 0) {
							$data['lignesErrors'] = array_merge($data['lignesErrors'], $tabResultCheckData['Scale']['lignesErrors']);
							$data['messageErrors'] = array_merge($data['messageErrors'], $tabResultCheckData['Scale']['messageErrors']);
							throw new Exception("Problème de données avec l'onglet Scale", 1);
						} //si vérification données ok
						else { //alors import
							if (!$this->Scale_model->import($tabResultCheckData['Scale']['import_data'])) {
								array_push($data['messageErrors'], "Erreur durant l'importation dans la base pour l'onglet Scale");
								throw new Exception("Erreur durant l'importation dans la base pour l'onglet Scale", 1);
							}
						}
					}

					if ($nbreDeLignesMethod > 1) {
						$tabResultCheckData['Method'] = $this->format_worksheetdata($worksheetArray['Method'], 'Method', $waiting_method_header);
						if (count($tabResultCheckData['Method']['lignesErrors']) > 0) {
							$data['lignesErrors'] = array_merge($data['lignesErrors'], $tabResultCheckData['Method']['lignesErrors']);
							$data['messageErrors'] = array_merge($data['messageErrors'], $tabResultCheckData['Method']['messageErrors']);
							throw new Exception("Problème de données avec l'onglet Method", 1);
						} else {
							if (!$this->Method_model->import($tabResultCheckData['Method']['import_data'])) {
								array_push($data['messageErrors'], "Erreur durant l'importation dans la base pour l'onglet Method");
								throw new Exception("Erreur durant l'importation dans la base pour l'onglet Method", 1);
							}
						}
					}

					if ($nbreDeLignesTarget > 1) {
						$tabResultCheckData['Target'] = $this->format_worksheetdata($worksheetArray['Target'], 'Target', $waiting_target_header);
						if (count($tabResultCheckData['Target']['lignesErrors']) > 0) {
							$data['lignesErrors'] = array_merge($data['lignesErrors'], $tabResultCheckData['Target']['lignesErrors']);
							$data['messageErrors'] = array_merge($data['messageErrors'], $tabResultCheckData['Target']['messageErrors']);
							throw new Exception("Problème de données avec l'onglet Target", 1);
						} else {
							if (!$this->Target_model->import($tabResultCheckData['Target']['import_data'])) {
								array_push($data['messageErrors'], "Erreur durant l'importation dans la base pour l'onglet Target");
								throw new Exception("Erreur durant l'importation dans la base pour l'onglet Target", 1);
							}
						}
					}

					if ($nbreDeLignesEntity > 1) {
						$tabResultCheckData['Entity'] = $this->format_worksheetdata($worksheetArray['Entity'], 'Entity', $waiting_entity_header);
						if (count($tabResultCheckData['Entity']['lignesErrors']) > 0) {
							$data['lignesErrors'] = array_merge($data['lignesErrors'], $tabResultCheckData['Entity']['lignesErrors']);
							$data['messageErrors'] = array_merge($data['messageErrors'], $tabResultCheckData['Entity']['messageErrors']);
							throw new Exception("Problème de données avec l'onglet Entity", 1);
						} else {
							if (!$this->Entity_model->import($tabResultCheckData['Entity']['import_data'])) {
								array_push($data['messageErrors'], "Erreur durant l'importation dans la base pour l'onglet Entity");
								throw new Exception("Erreur durant l'importation dans la base pour l'onglet Entity", 1);
							}
						}
					}

					if ($nbreDeLignesTrait > 1) {
						$tabResultCheckData['Trait'] = $this->format_worksheetdata($worksheetArray['Trait'], 'Trait', $waiting_trait_header);
						if (count($tabResultCheckData['Trait']['lignesErrors']) > 0) {
							$data['lignesErrors'] = array_merge($data['lignesErrors'], $tabResultCheckData['Trait']['lignesErrors']);
							$data['messageErrors'] = array_merge($data['messageErrors'], $tabResultCheckData['Trait']['messageErrors']);
							throw new Exception("Problème de données avec l'onglet Trait", 1);
						} else {
							if (!$this->Trait_model->import($tabResultCheckData['Trait']['import_data'])) {
								array_push($data['messageErrors'], "Erreur durant l'importation dans la base pour l'onglet Trait");
								throw new Exception("Erreur durant l'importation dans la base pour l'onglet Trait", 1);
							}
						}
					}

					$tabResultCheckData['Variable'] = $this->format_worksheetdata($worksheetArray['Variable'], 'Variable', $waiting_variable_header);
					if (count($tabResultCheckData['Variable']['lignesErrors']) > 0) {
						$data['lignesErrors'] = array_merge($data['lignesErrors'], $tabResultCheckData['Variable']['lignesErrors']);
						$data['messageErrors'] = array_merge($data['messageErrors'], $tabResultCheckData['Variable']['messageErrors']);
						throw new Exception("Problème de données avec l'onglet Variable", 1);
					} else {
						if (!$this->Variable_model->import($tabResultCheckData['Variable']['import_data'])) {
							array_push($data['messageErrors'], "Erreur durant l'importation dans la base pour l'onglet Variable");
							throw new Exception("Erreur durant l'importation dans la base pour l'onglet Variable", 1);
						}
					}
					unlink($upload_data['full_path']); //remove file
					$this->view('variable/import_success', $page['title'], $page['subtitle'], $data, $scripts);
				} else {
					unlink($upload_data['full_path']); //remove file
					$this->view('variable/import', $page['title'], $page['subtitle'], $data, $scripts);
				}
			} catch (Exception $e) {
				$this->view('variable/import_success', $page['title'], $page['subtitle'], $data, $scripts);
				unlink($upload_data['full_path']); // remove file
				//show_error($e->getmessage());
			}
		}
	}

	public function import1()
	{
		$page['title'] = "Importation des variables";
		$page['subtitle'] = "Formulaire d'importation des variables";

		$config['upload_path'] = UPLOAD_PATH; //Le chemin d'accès au répertoire où le téléchargement doit être placé.
		$config['allowed_types'] = 'xls|xlsx'; // Autres extensions de la librairie phpexcel xml|ods|slk|gnumeric|csv|htm|html
		$config['encrypt_name'] = TRUE;

		//$this->load->library('excel');
		//$this->load->library('table');
		$this->load->library('upload', $config);
		$scripts = array('bootstrap-select-ajax-plugin');
		$data = array();

		$this->load->model(array('Entity_model', 'Target_model', 'Trait_model', 'Method_model', 'Scale_model'));
		

		$this->view('variable/import', $page['title'], $page['subtitle'], $data, $scripts);
		
	}

	public function processImport(){
		$config['upload_path'] = UPLOAD_PATH; //Le chemin d'accès au répertoire où le téléchargement doit être placé.
		$config['allowed_types'] = 'xls|xlsx'; // Autres extensions de la librairie phpexcel xml|ods|slk|gnumeric|csv|htm|html
		$config['encrypt_name'] = TRUE;
		$this->load->library('upload', $config);
		
		$this->load->model(array('Entity_model', 'Target_model', 'Trait_model', 'Method_model', 'Scale_model','Variable_model'));

		$upload_file = $_FILES['variable_file']['name'];
		if ($upload_file != NULL) {
			$extension = pathinfo($upload_file,PATHINFO_EXTENSION);

			if($extension == 'xls'){
				$reader = new \PhpOffice\PhpSpreadsheet\Reader\Xls();
			}else{
				$reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
			}

			$reader->setLoadAllSheets();
			$spreadsheet = $reader->load($_FILES['variable_file']['tmp_name']);
			$ListData = array();
			
		
			$sheetOnglet = ['Variable','Entity','Target','Trait','Method','Scale'];
			$data = array();

			for ($i=0; $i < count($sheetOnglet); $i++) { 
				$reader->setLoadSheetsOnly($sheetOnglet[$i]);
				$spreadsheet = $reader->load($_FILES['variable_file']['tmp_name']);
				$sheetData = $spreadsheet->getActiveSheet()->toArray();

				$temp_array = array();
				for ($k=1; $k < count($sheetData); $k++) { 
					// les lignes 
					//array_push($temp_arr,$sheetData[$k]);
					$temp_arr = array();
					for ($j=0; $j < count($sheetData[$k]); $j++) { //on spécifier les keys

						//certains noms de colonne n'ont plus le même nom dans la bdd !
						if ($sheetData[0][$j] == 'trait_entity_code') {
							$temp_arr['trait_entity'] = $sheetData[$k][$j];
						}else {
							if ($sheetData[0][$j] == 'trait_target_name') {
								$temp_arr['trait_target'] = $sheetData[$k][$j];
							}else {
								$temp_arr[$sheetData[0][$j]] = $sheetData[$k][$j];
							}
						}
						
					}
					array_push($temp_array,$temp_arr);
				}
				$ListData[$sheetOnglet[$i]] = $temp_array;
				
			}

			// Notre fichier est convertie en tableau : $ListData;
			// Ensuite, nous verifions si les informations devront être créer ou pas.
			
			$count_element_create = 0;
			$count_variable_create = 0;
			$count_error_element_create = 0;
			$count_error_variable_create = 0;
			$count_already_variable = 0;

			$list_trait_code = [];
			$list_entity_code = [];
			$list_method_code = [];
			$list_scale_code = [];

			for ($i=0; $i < count($ListData['Trait']); $i++) array_push($list_trait_code, $ListData['Trait'][$i]['trait_code']);
			for ($i=0; $i < count($ListData['Entity']); $i++) array_push($list_entity_code, $ListData['Entity'][$i]['entity_code']);
			for ($i=0; $i < count($ListData['Method']); $i++) array_push($list_method_code, $ListData['Method'][$i]['method_code']);
			for ($i=0; $i < count($ListData['Scale']); $i++) array_push($list_scale_code, $ListData['Scale'][$i]['scale_code']);
			
			//echo '<pre>';
			//print_r($ListData);
			
			for ($i=0; $i < count($ListData['Variable']); $i++) { 
				$row_variable = $ListData['Variable'][$i];
				//verifie si le code variable exist
				if($this->Variable_model->exist($row_variable['variable_code'])==TRUE){
					$count_already_variable += 1;
					//print_r($row_variable['variable_code'] . ' existe !! <br>');
				}else{
					//champs remplis ?
					if (!$this->all_filled($row_variable) == TRUE) {
						$count_error_variable_create += 1;
					}else{
						//on verifie si les élements renseigné sont correctes dans les autres onglets.
						if (!in_array($row_variable['trait_code'],$list_trait_code) == TRUE &&
							!in_array($row_variable['method_code'],$list_method_code) == TRUE &&
							!in_array($row_variable['scale_code'],$list_scale_code) == TRUE) {
							$count_error_variable_create += 1;
							
							if(in_array($row_variable['trait_code'],$list_trait_code) == TRUE) $count_error_element_create += 1;
							if(in_array($row_variable['method_code'],$list_method_code) == TRUE) $count_error_element_create += 1;
							if(in_array($row_variable['scale_code'],$list_scale_code) == TRUE) $count_error_element_create += 1;
						}else{
							// si l'élément trait n'exite pas dans la bdd, on la crée
							if (!$this->Trait_model->exist($row_variable['trait_code'])) {
								//on trouve les elements du trait
								for ($j=0; $j < count($ListData['Trait']); $j++) { 
									$row_trait = $ListData['Trait'][$j];
									if ($row_trait['trait_code'] ==  $row_variable['trait_code']) {
										//check Entity
										for ($k=0; $k < count($ListData['Entity']); $k++) { 
											$row_entity = $ListData['Entity'][$k];
											//on verifie si les entity_code  correspondent:
											if ($row_trait['trait_entity_code'] == $row_entity['entity_code']) {
												if (!$this->Entity_model->exist($row_trait['trait_entity_code']) == TRUE) {
													if ($this->Entity_model->create($row_entity)==TRUE) {
														$count_element_create += 1;
													}
												}
											}
										}
										//check Target
										for ($k=0; $k < count($ListData['Target']); $k++) { 
											$row_target = $ListData['Target'][$k];
											if ($row_target['target_name'] == $row_trait['trait_target_name']) {
												if (!$this->Target_model->exist($row_target['target_name'])) {//si taget name n'existe pas on créer une variable
													$this->Target_model->create($row_target);
												}
											}
										}
										// Création du Trait
										$this->Trait_model->create($row_trait);
										
									}
								}
								
							}

							if (!$this->Method_model->exist($row_variable['method_code'])) {
								for ($i=0; $i < count($ListData['Method']); $i++) { 
									$row_method = $ListData['Method'][$i];
									if ($row_method['method_code'] == $row_variable['method_code']) {
										if ($this->Method_model->create($row_method) == TRUE) {
											$count_element_create += 1;
										}
									}
								}
							}

							if (!$this->Scale_model->exist($row_variable['scale_code'])) {
								for ($i=0; $i < count($ListData['Scale']); $i++) { 
									$row_scale = $ListData['Scale'][$i];
									if ($row_scale['scale_code'] == $row_variable['scale_code']) {
										if ($this->Scale_model->create($row_scale) == TRUE) {
											$count_element_create +=1;
										}
									}
								}
							}
							$today = date("Y-m-d"); 
							$row_variable["entry_date"] = $today;
							//print_r($row_variable);
							if ($this->Variable_model->create($row_variable)==TRUE) {
								//print_r('success !!');
								$count_variable_create +=1;
							}
						}
					}
				}
				
			}


			$info = [];
			$info['var_create'] = $count_variable_create;
			$info['var_exist'] = $count_already_variable;
			$info['var_error'] = $count_error_variable_create;
			$info['element_create'] = $count_element_create;
			$info['element_error'] = $count_error_element_create;

			$info['total_var'] = $count_variable_create + $count_error_variable_create + $count_already_variable;
			$info['total_element'] = $count_element_create + $count_error_element_create;

			//print_r($info);
			$page['title'] = 'Importation';
			$page['subtitle'] = 'Information';
			$scripts = array('bootstrap-select-ajax-plugin');
			$data['info'] = $info;
			$this->view('variable/import_success', $page['title'], $page['subtitle'], $data, $scripts);
			
		}
		
		
				
	}

	public function all_filled($data){
		foreach ($data as $key => $value) {
			if (empty($value)) {
				return FALSE;
			}
		}
		return TRUE;
	}
	

	/**
	 * Retourne le nom du champ (formaté), si une chaine de caractères est un nom de champ valide
	 * pour le formulaire d'importation des données liées à une var. Sinon retourne FALSE
	 */
	public function format_field($field, $waiting_main_header)
	{
		if (in_array(strtolower($field), $waiting_main_header)) {
			return strtolower($field);
		} else {
			return FALSE;
		}
	}

	//fonction retournant la matrice de donnees verifiees et les lignes erreurs ainsi que leur message
	public function format_worksheetdata($worksheetdata, $worksheetname, $checking_header)
	{

		$header = array(); // init du tableau qui contiendra les variables que l on souhaite importer
		$lineErrors = array(); //tab qui contiendra les num de ligne du fichier dimport ou un probleme a ete rencontre
		$messageErrors = array(); //tab contenant les messages d erreur genere lors de l import
		//$array_Line_Message_Data = array();

		foreach ($worksheetdata->getRowIterator() as $row) { //parcours de chaque ligne de la feuille
			$cellIterator = $row->getCellIterator(); //recupere un iterateur de ttes les cellules de la ligne actuelle
			$cellIterator->setIterateOnlyExistingCells(FALSE); //Permet à itérateur de pas occulter et prendre en compte les cellules vides

			foreach ($cellIterator as $cell) { //parcours de chaque cellule de la ligne
				$cell_column = $cell->getColumn();
				$cell_row = $cell->getRow();
				$data_value = xss_clean($cell->getFormattedValue()); //recupere la valeur sans formatage de cellule appliquee

				if ($cell_row == 1) { //  si en-tete du fichier
					// Vérification du header, si nom colonne present dans la base
					$field = $this->format_field($data_value, $checking_header);

					if ($field) { //si la colonne du fichier d'import appartient à la base
						$header[$cell_column] = $field; //ajout du nom du champ dans le tableau header indexe par les num de col dans la feuille excel
					} elseif ($data_value) {
						array_push($messageErrors, "La colonne " . $cell_column . " de la feuille " . $worksheetname . ", n'existe pas dans la base");
					}
				} else {
					// Vérification des valeurs
					if (isset($header[$cell_column]) && $data_value) {  // Si la colonne de la donnée fait réference à un champ défini dans le header
						switch ($worksheetname) { //test sur le nom de la feuille
							case 'Variable':
								switch ($header[$cell_column]) { //test sur le nom de colonne
									case 'variable_code':
										if ($this->Variable_model->find(array('variable_code' => $data_value))) {
											array_push($messageErrors, "Variable_code, ligne " . $cell_row . " feuille " . $worksheetname . ", existe déjà dans la base");
											array_push($lineErrors, $cell_row);
											$import_data[$cell_row][$header[$cell_column]] = NULL;
										} else $import_data[$cell_row][$header[$cell_column]] = $data_value;
										break;
									case 'trait_code':
										if (!$this->Trait_model->find(array('trait_code' => $data_value))) {
											array_push($messageErrors, "Trait_code, ligne " . $cell_row . " feuille " . $worksheetname . ", n'existe pas dans la base");
											array_push($lineErrors, $cell_row);
											$import_data[$cell_row][$header[$cell_column]] = NULL;
										} else $import_data[$cell_row][$header[$cell_column]] = $data_value;
										break;
									case 'method_code':
										if (!$this->Method_model->find(array('method_code' => $data_value))) {
											array_push($messageErrors, "method_code, ligne " . $cell_row . " feuille " . $worksheetname . ", n'existe pas dans la base");
											array_push($lineErrors, $cell_row);
											$import_data[$cell_row][$header[$cell_column]] = NULL;
										} else $import_data[$cell_row][$header[$cell_column]] = $data_value;
										break;
									case 'scale_code':
										if (!$this->Scale_model->find(array('scale_code' => $data_value))) {
											array_push($messageErrors, "scale_code, ligne " . $cell_row . " feuille " . $worksheetname . ", n'existe pas dans la base");
											array_push($lineErrors, $cell_row);
											$import_data[$cell_row][$header[$cell_column]] = NULL;
										} else $import_data[$cell_row][$header[$cell_column]] = $data_value;
										break;
								}
								break;
							case 'Entity':
								if ($header[$cell_column] == 'entity_code') {
									if ($this->Entity_model->find(array('entity_code' => $data_value))) {
										array_push($messageErrors, "entity_code, ligne " . $cell_row . " feuille " . $worksheetname . ", existe déjà dans la base");
										array_push($lineErrors, $cell_row);
										$import_data[$cell_row][$cell_column] = NULL;
									} else $import_data[$cell_row][$header[$cell_column]] = $data_value;
								}
								break;
							case 'Target':
								if ($header[$cell_column] == 'target_name') {
									if ($this->Target_model->find(array('target_name' => $data_value))) {
										array_push($messageErrors, "target_name, ligne " . $cell_row . " feuille " . $worksheetname . ", existe déjà dans la base");
										array_push($lineErrors, $cell_row);
										$import_data[$cell_row][$cell_column] = NULL;
									} else $import_data[$cell_row][$header[$cell_column]] = $data_value;
								}
								break;
							case 'Trait':
								switch ($header[$cell_column]) {
									case 'trait_code':
										if ($this->Trait_model->find(array('trait_code' => $data_value))) {
											array_push($messageErrors, "trait_code, ligne " . $cell_row . " feuille " . $worksheetname . ", existe déjà dans la base");
											array_push($lineErrors, $cell_row);
											$import_data[$cell_row][$cell_column] = NULL;
										} else $import_data[$cell_row][$header[$cell_column]] = $data_value;
										break;

									case 'trait_entity_code':
										if (!$this->Entity_model->find(array('entity_code' => $data_value))) {
											array_push($messageErrors, "entity_code, ligne " . $cell_row . " feuille " . $worksheetname . ", n'existe pas dans la base");
											array_push($lineErrors, $cell_row);
											$import_data[$cell_row][$cell_column] = NULL;
										} else $import_data[$cell_row][$header[$cell_column]] = $data_value;
										break;

									case 'trait_target_name':
										if (!$this->Target_model->find(array('target_name' => $data_value))) {
											array_push($messageErrors, "target_name, ligne " . $cell_row . " feuille " . $worksheetname . ", n'existe pas dans la base");
											array_push($lineErrors, $cell_row);
											$import_data[$cell_row][$cell_column] = NULL;
										} else $import_data[$cell_row][$header[$cell_column]] = $data_value;
										break;
								}
								break;
							case 'Method':
								if ($header[$cell_column] == 'method_code') {
									if ($this->Method_model->find(array('method_code' => $data_value))) {
										array_push($messageErrors, "method_code, ligne " . $cell_row . " feuille " . $worksheetname . ", existe déjà dans la base");
										array_push($lineErrors, $cell_row);
										$import_data[$cell_row][$cell_column] = NULL;
									} else $import_data[$cell_row][$header[$cell_column]] = $data_value;
								}
								break;
							case 'Scale':
								if ($header[$cell_column] == 'scale_code') {
									if ($this->Scale_model->find(array('scale_code' => $data_value))) {
										array_push($messageErrors, "scale_code, ligne " . $cell_row . " feuille " . $worksheetname . ", existe déjà dans la base");
										array_push($lineErrors, $cell_row);
										$import_data[$cell_row][$cell_column] = NULL;
									} else $import_data[$cell_row][$header[$cell_column]] = $data_value;
								}
								break;
						}
					} elseif (isset($header[$cell_column])) {
						switch ($worksheetname) {
							case 'Variable':
								switch ($header[$cell_column]) {
									case 'variable_code':
										array_push($messageErrors, "variable_code, ligne " . $cell_row . " feuille " . $worksheetname . ", absent");
										array_push($lineErrors, $cell_row);
										break;
									case 'trait_code':
										array_push($messageErrors, "trait_code, ligne " . $cell_row . " feuille " . $worksheetname . ", absent");
										array_push($lineErrors, $cell_row);
										break;
									case 'method_code':
										array_push($messageErrors, "method_code, ligne " . $cell_row . " feuille " . $worksheetname . ", absent");
										array_push($lineErrors, $cell_row);
										break;
									case 'scale_code':
										array_push($messageErrors, "scale_code, ligne " . $cell_row . " feuille " . $worksheetname . ", absent");
										array_push($lineErrors, $cell_row);
										break;
								}
								break;
							case 'Entity':
								if ($header[$cell_column] == 'entity_code') {
									array_push($messageErrors, "entity_code, ligne " . $cell_row . " feuille " . $worksheetname . ", absent");
									array_push($lineErrors, $cell_row);
								}
								break;
							case 'Target':
								if ($header[$cell_column] == 'target_name') {
									array_push($messageErrors, "target_name, ligne " . $cell_row . " feuille " . $worksheetname . ", absent");
									array_push($lineErrors, $cell_row);
								}
								break;
							case 'Trait':
								switch ($header[$cell_column]) {
									case 'trait_code':
										array_push($messageErrors, "trait_code, ligne " . $cell_row . " feuille " . $worksheetname . ", absent");
										array_push($lineErrors, $cell_row);
										break;

									case 'trait_entity_code':
										array_push($messageErrors, "entity_code, ligne " . $cell_row . " feuille " . $worksheetname . ", absent");
										array_push($lineErrors, $cell_row);
										break;

									case 'trait_target_name':
										array_push($messageErrors, "target_name, ligne " . $cell_row . " feuille " . $worksheetname . ", absent");
										array_push($lineErrors, $cell_row);
										break;
								}
								break;
							case 'Method':
								if ($header[$cell_column] == 'method_code') {
									array_push($messageErrors, "method_code, ligne " . $cell_row . " feuille " . $worksheetname . ", absent");
									array_push($lineErrors, $cell_row);
								}
								break;
							case 'Scale':
								if ($header[$cell_column] == 'scale_code') {
									array_push($messageErrors, "scale_code, ligne " . $cell_row . " feuille " . $worksheetname . ", absent");
									array_push($lineErrors, $cell_row);
								}
								break;
						}
						$import_data[$cell_row][$header[$cell_column]] = NULL;
					}
				}
			}
		}

		$array_Line_Message_Data['lignesErrors'] = $lineErrors;
		$array_Line_Message_Data['messageErrors'] = $messageErrors;
		$array_Line_Message_Data['import_data'] = $import_data;

		return $array_Line_Message_Data;
	}


	//Treeview 

	public function treeview()
	{
		$data['distinctClass'] = $this->Variable_model->getDistinctClass();
		$data['distinctSubclass'] = $this->Variable_model->getDistinctSubclass();
		$data['distinctDomain'] = $this->Variable_model->getDistinctDomain();
		$this->view('treeview/variable', 'Dictionnaire des variables', 'Séléction des variables AEGIS', $data);
	}

	public function initClass(){
		echo json_encode($this->Variable_model->getDistinctClass());
	}

	public function initSubclass(){
		echo json_encode($this->Variable_model->getDistinctSubclass());
	}

	public function initDomain(){
		echo json_encode($this->Variable_model->getDistinctDomain());
	}

	public function get_all_variable(){
		echo json_encode($this->Variable_model->get_all_variable());
	}

	public function getVarInfo()
	{
		$var_id =  $this->input->post("id");
		echo json_encode($this->Variable_model->getVariableAllInfo($var_id));
	}

	public function getResult()
	{
		// echo json_encode(($this->Variable_model->getAllVar())); 
		echo json_encode(($this->Variable_model->getCommonVar()));
		
	}

	// validation 
	public function getInvalidVariable(){
		echo json_encode($this->saisie_variable_model->get_invalid_variable());
	}

	//Hierarchical Edge Bundling

	public function getVarAndCommon(){
		//$cond = $this->input->post("condition");
		$class = $this->input->post("class");
		$subclass = $this->input->post("subclass");
		$domain = $this->input->post("domain");

		$CSD = array('class' => $class, 'subclass' => $subclass, 'domain' => $domain);
		$arr = array();
		
		foreach($CSD as $key => $value){
			if ($value) {
				//array_push($arr, );
				$arr[$key] = $value;
			}
		}
		
		if ($class || $subclass || $domain) {
			$cond = array('class' => $class, 'subclass' => $subclass, 'domain' => $domain);
		}else{
			$cond = null;
		}
		

		echo json_encode(($this->Variable_model->getVarAndCommon($arr)));
	}
	
}
