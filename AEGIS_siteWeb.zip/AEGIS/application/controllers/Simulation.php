<?php
defined('BASEPATH') or exit('No direct script access allowed');

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class Simulation extends MY_Controller
{
    public function __construct()
	{
		parent::__construct();
		if (!$this->session->userdata('connected')) {
			set_status_header(401);
			show_error("Vous devez être connecté pour accéder à cette page. <a href=\"" . site_url('welcome/login') . "\">Connexion</a>", 401);
			return;
		}

		$this->load->helper(array('form', 'url'));
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<div class="alert alert-danger"><span class="glyphicon glyphicon-warning-sign"></span>', '</div>');
		$this->load->model('Simulation_model');

	}

    public function index()
	{
		// Titre de la page
		$page['title'] = 'Simulation';
		$page['subtitle'] = '';
		
        $data['Projects'] = $this->Simulation_model->getAllProjects();
        // $data['Trial'] = $this->Simulation_model->getTrialsFromProject('ICSM');
		// $data['Starting_date'] = $this->Simulation_model->getDateFromTrial($data['Trial'][0]['trial_code']);
		// echo '<pre>';
		//print_r($data['Starting_date']);

		$scripts = array('bootstrap-select-ajax-plugin','simulation');
		$this->view('simulation/simulation', $page['title'], $page['subtitle'], $data, $scripts);
	}

	public function getTrialfromProject(){
		$code = $this->input->post('code');
		echo json_encode($this->Simulation_model->getTrialsFromProject($code));
	}

	public function getDatefromTrial(){
		$code = $this->input->post('code');
		echo json_encode($this->Simulation_model->getDateFromTrial($code));
	}

	public function getDataFromFilter(){
		$project = $this->input->post('project');
		$trial = $this->input->post('trial');
		$date = $this->input->post('date');
		// $tab['project_code'] = $this->input->post('project');
		// $tab['trial_code'] =  $this->input->post('trial');
		// $tab['starting_date'] = $this->input->post('date');
		echo json_encode($this->Simulation_model->getdatawhithfilter($project,$trial,$date));
	}
}

?>