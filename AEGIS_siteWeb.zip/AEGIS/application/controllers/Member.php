<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
* Contrôleur de l'espace membre.
*
* @author Medhi Boulnemour <boulnemour.medhi@live.fr>
*/
class Member extends MY_Controller{

  public function __construct()
  {
    parent::__construct();
    $this->load->model('Users_model');
    //$this->load->model('Group_model');
    $this->load->library('form_validation');

    if($this->session->userdata('connected') != TRUE) {
      show_error("Vous n'êtes pas autorisé(e) à lire cette page!", 403);
      return;
    }

    $this->load->add_package_path(APPPATH.'third_party/ion_auth/');
    $this->load->library('ion_auth');
  }

  function index()
  {
    redirect("Member/profil", "location");
    return;
  }

  /**
  * Page profil de l'utilisateur
  */
  public function profil()
  {
    //Règles du formulaire
    $this->form_validation->set_rules('email', '"E-mail"', 'required|valid_email|xss_clean'); // TODO: verifier que l'adresse mail n'existe pas deja pour un autre compte
    $this->form_validation->set_rules('first_name', '"Prénom"', 'required|trim|min_length[2]'
    .'|max_length[50]|alpha_dash'
    .'|encode_php_tags|xss_clean');
    $this->form_validation->set_rules('last_name', '"Nom"', 'required|trim|min_length[2]|max_length[50]'
    .'|alpha_dash|encode_php_tags|xss_clean');

    $data['update_status'] = NULL;

    if($this->form_validation->run()){
      //On applique les changements
      $new_user_data = array(
        'first_name' => $this->input->post('first_name'),
        'last_name' => $this->input->post('last_name'),
        'email' => $this->input->post('email')
      );

      $data['update_status'] = $this->Users_model->set_user_data($this->session->userdata('username'), $new_user_data);

    }
    $data['user_infos'] = $this->Users_model->get_user_data($this->session->userdata('username'));

    $this->view('member/profil', 'Paramètres du profil', 'Informations à propos de votre profil AEGIS', $data);
  }

  /**
  * Page changement de mot de passe de l'utilisateur
  */
  public function password()
  {
    //Règles du formulaire
    $this->form_validation->set_rules('new_mdp', '"Mot de passe"',	'required|min_length[5]'
    .'|max_length[52]|alpha_dash'
    .'|encode_php_tags'
    .'|matches[mdp_conf]|xss_clean');
    $this->form_validation->set_rules('mdp_conf', '"Confirmation du mot de passe"','required'
    .'|min_length[5]|max_length[52]'
    .'|alpha_dash|encode_php_tags|xss_clean');
    $this->form_validation->set_rules('mdp', '"Mot de passe"', 'required|encode_php_tags'
    .'|callback_valid_password['.$this->session->userdata('username').']|xss_clean');

    $data['update_status'] = NULL;

    if($this->form_validation->run()){
      //Après avoir tout vérifié dans le formulaire, on update le mot de passe dans la bdd grâce à Ion Auth
      $data['update_status'] = $this->ion_auth->reset_password($this->session->userdata('username'), $this->input->post('new_mdp'));
    }

    $data['user_infos'] = $this->Users_model->get_user_data($this->session->userdata('username'));
    $this->view('member/password', 'Mot de Passe', 'Vous pouvez changer votre mot de passe à partir de cette page.', $data);
  }

  /**
   * Indique à la base que le volet de notification a été ouvert.
   */
  public function notifications_read()
  {
    $this->load->model('Notification_model');
    $this->Notification_model->update(array('target_login' => $this->session->userdata('username')), array('was_read' => TRUE));
  }

  



  /**
  * Test
  * Update member
  */
    public function update_member(){

        if (!$this->session->userdata('admin')) {
            set_status_header(401);
            show_error("vous n'êtes pas autorisé à lire cette page.", 401);
            return;
        }

        //Règles du formulaire d'inscription
        $this->form_validation->set_rules('pseudo', '"Identifiant"','trim|required|min_length[3]|xss_clean'
        .'|max_length[30]|alpha_dash'
        .'|encode_php_tags'
        .'|is_unique[users.username]');
        $this->form_validation->set_rules('mdp', '"Mot de passe"',  'required|min_length[5]|xss_clean'
        .'|max_length[52]|alpha_dash'
        .'|encode_php_tags'
        .'|matches[mdp_conf]');
        $this->form_validation->set_rules('new_mdp', '"Mot de passe"',  'required|min_length[5]'
        .'|max_length[52]|alpha_dash'
        .'|encode_php_tags'
        .'|matches[mdp_conf]|xss_clean');
        $this->form_validation->set_rules('mdp_conf', '"Confirmation du mot de passe"','required|xss_clean'
        .'|min_length[5]|max_length[52]'
        .'|alpha_dash|encode_php_tags');
        $this->form_validation->set_rules('email', '"E-mail"', 'required|valid_email|xss_clean'
        .'|is_unique[users.email]');
        $this->form_validation->set_rules('first_name', '"Prénom"', 'required|trim|min_length[2]|xss_clean'
        .'|max_length[50]|alpha_dash'
        .'|encode_php_tags');
        $this->form_validation->set_rules('last_name', '"Nom"', 'required|trim|min_length[2]|max_length[50]|xss_clean'
        .'|alpha_dash|encode_php_tags');
        $this->form_validation->set_rules('organization', '"Organisation"', 'trim|is_natural|xss_clean'
        .'|encode_php_tags');

        $data['username'] = $this->input->post('pseudo');
        $data['mdp'] = $this->input->post('mdp');
        $data['new_mdp'] = $this->input->post('new_mdp');
        $data['mdp_conf'] = $this->input->post('mdp_conf');
        $data['email'] = $this->input->post('email');
        $data['first_name'] = $this->input->post('first_name');
        $data['last_name'] = $this->input->post('last_name');
        $data['organization'] = $this->input->post('organization');

        //On recupère la liste des organisations
        $this->load->model('Partner_model');
        $data['list_partner'] = $this->Partner_model->find();

        if($this->form_validation->run()){

          //On applique les changements
          $additional_data = array(
            'ip_address' => $this->input->ip_address(),
            'first_name' => $data['first_name'],
            'last_name' => $data['last_name'],
            'created_on' => time(),
            'created_on_readable' => date('Y-m-d H:i:s'),
            'last_login' => time(),
            'active' => 1
          );

          //L'organisation est facultative
          if($data['organization']) $additional_data += array('partner' => $data['organization']);

          $this->ion_auth->register($data['username'], $data['mdp'], $data['email'], $additional_data);

          //On enregistre les données de l'utilisateur pour la session
          $user_data = $data;

          //On retire le mot de passe des futur variables de session
          unset($user_data['mdp']);
          unset($user_data['mdp_conf']);

          $user_data['connected'] = TRUE;
          $this->session->set_userdata($user_data);

          // Alerte les administrateurs (Notifications & Email)
          $this->load->library('email');
          $this->load->model('Notification_model');

          $this->email->from($user_data['email'], $user_data['username']);
          $this->email->to(AEGIS_MAIL);
          

          $this->email->subject("[Modifications] Un membre vient d'effectuer des modifications sur un utilisateur d' AEGIS ".$user_data['username']);
          $this->email->message(
            "Les information d'utilisateur AEGIS ont était modifé.\n\n
            login : ".$data['username']."\n
            email : ".$data['email']."\n
            first_name : ".$data['first_name']."\n
            last_name : ".$data['last_name']."\n
            organization : ".$data['organization']
          );

          $this->email->send();

          // Test
          //'target_login' => $admin['login']
          //'ressource' => $user_data['login']
          $admins = $this->Users_model->find(array('admin' => PGSQL_TRUE));
          foreach ($admins as $admin) {
            $this->Notification_model->create(array(
              'target_login' => $admin['username'],
              'notification_type' => NEW_USER,
              'sender_login' => $data['username'],
              'created_time' => 'NOW()',
              'ressource' => $data['username']
            ));
          }
          

          //Redirection
          redirect("Welcome/index", "location");
          return;
        }
        $scripts = array( 'selectize',
                          'verifie_pseudo',
                          'init_organization_select'
                        );
        
        
        $this->view('member/update_member', 'Modification' . $data['username'], 'Vous pouvez effectuer des modifications à partir de cette page.' . $data['username'], $data);


        /**
        $this->view('member/update_member', 'Modification', 'Vous pouvez effectuer des modifications à partir de cette page.', $data);**/

    }//end_update_member 

}
