<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
* Controleur principal de l'application web AEGIS
*
* @author Medhi Boulnemour <boulnemour.medhi@live.fr>
*/
class Contact extends MY_Controller {

  /**
  * Contructeur du controleur
  * Il est éxécuté avant d'appler les pages de du controleur 'Contact'
  */
  public function __construct() {
    parent::__construct();
    $this->load->model('Users_model');
    $this->load->library('form_validation');
    //$this->form_validation->set_error_delimiters('<div class="alert alert-danger"><span class="glyphicon glyphicon-warning-sign"></span>', '</div>');

    $this->load->add_package_path(APPPATH.'third_party/ion_auth/');
    $this->load->library('ion_auth');
  }

  public function index() {
    $this->view();
  }

  public function send(){
    if(isset($_POST['email'])) {
     
        // EDIT THE 2 LINES BELOW AS REQUIRED
        $email_to = AEGIS_MAIL;
        $email_subject = "From AEGIS";
     
        function died($error) {
            // your error code can go here
            echo "We are very sorry, but there were error(s) found with the form you submitted. ";
            echo "These errors appear below.<br /><br />";
            echo $error."<br /><br />";
            echo "Please go back and fix these errors.<br /><br />";
            die();
        }
     
     
        // validation expected data exists
        if(!isset($_POST['first_name']) ||
            !isset($_POST['last_name']) ||
            !isset($_POST['email']) ||
            //!isset($_POST['telephone']) ||
            !isset($_POST['comments'])) {
            died('We are sorry, but there appears to be a problem with the form you submitted.');       
        }
     
         
     
        $first_name = $_POST['first_name']; // required
        $last_name = $_POST['last_name']; // required
        $email_from = $_POST['email']; // required
        $telephone = $_POST['telephone']; // not required
        $comments = $_POST['comments']; // required
     
        $error_message = "";
        $email_exp = '/^[A-Za-z0-9._%-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$/';
     
      if(!preg_match($email_exp,$email_from)) {
        $error_message .= 'The Email Address you entered does not appear to be valid.<br />';
      }
     
        $string_exp = "/^[A-Za-z .'-]+$/";
     
      if(!preg_match($string_exp,$first_name)) {
        $error_message .= 'The First Name you entered does not appear to be valid.<br />';
      }
     
      if(!preg_match($string_exp,$last_name)) {
        $error_message .= 'The Last Name you entered does not appear to be valid.<br />';
      }
     
      if(strlen($comments) < 2) {
        $error_message .= 'The Comments you entered do not appear to be valid.<br />';
      }
     
      if(strlen($error_message) > 0) {
        died($error_message);
      }
     
        $email_message = "Form details below.\n\n";
     
         
        function clean_string($string) {
          $bad = array("content-type","bcc:","to:","cc:","href");
          return str_replace($bad,"",$string);
        }
     
         
     
        $email_message .= "First Name: ".clean_string($first_name)."\n";
        $email_message .= "Last Name: ".clean_string($last_name)."\n";
        $email_message .= "Email: ".clean_string($email_from)."\n";
        $email_message .= "Telephone: ".clean_string($telephone)."\n";
        $email_message .= "Comments: ".clean_string($comments)."\n";
     
    // create email headers
    $headers = 'From: '.$email_from."\r\n".
    'Reply-To: '.$email_from."\r\n" .
    'X-Mailer: PHP/' . phpversion();
    @mail($email_to, $email_subject, $email_message, $headers);  

    /*
    // send or not
    if (mail($email_to, $email_subject, $email_message, $headers))
    {
        echo 'Message envoyé';
    } else
    {
        echo "Une erreur est survenue lors de l'envoi du formulaire par email";
        echo " (".$email_to.",".$email_subject.",".$email_message.")";
    }
     
    */
    
     
    //<!-- include your own success html here -->
     
    //Thank you for contacting us. We will be in touch with you very soon.
     
    
     
    }//end if
    
    
    # Configuration de l'envoi ...
    if(!@mail($email_to, $email_subject, $email_message, $headers)){
    // Si une erreur est survenue lors de l'envoi du message ...
      echo "<b>Erreur lors de l'envoi du Mail !</b>";
    } else {
    // Si le message a correctement été envoyé ...
      echo "Message envoyé !<br><br>De : <b>$from</b> <i>[$from_add]</i><br>A : <b>$to</b> <i>[$email_to]</i><br>Sujet : <b>$email_subject</b>";
    }


     $this->view('welcome/contact', 'Nous Contacter', 'Vous pouvez nous contacter à partir de cette page.');
  }//end_send


  /**
  * Test
  * Envoi
  */
    public function envoi(){

        if (!$this->session->userdata('admin')) {
            set_status_header(401);
            show_error("vous n'êtes pas autorisé à lire cette page.", 401);
            return;
        }

        //Règles du formulaire d'inscription
        $this->form_validation->set_rules('msg', '"Message"','trim|required|min_length[100]|xss_clean'
        .'|max_length[100]|alpha_dash'
        .'|encode_php_tags'
        .'|is_unique[users.username]');
        $this->form_validation->set_rules('email', '"E-mail"', 'required|valid_email|xss_clean'
        .'|is_unique[users.email]');
        $this->form_validation->set_rules('sujet', '"Sujet"', 'required|trim|min_length[2]|xss_clean'
        .'|max_length[50]|alpha_dash'
        .'|encode_php_tags');
        $this->form_validation->set_rules('last_name', '"Nom"', 'required|trim|min_length[2]|max_length[50]|xss_clean'
        .'|alpha_dash|encode_php_tags');
        

        $data['msg'] = $this->input->post('msg');
        $data['email'] = $this->input->post('email');
        $data['sujet'] = $this->input->post('sujet');
        $data['last_name'] = $this->input->post('last_name');

        //On recupère la liste des organisations
        $this->load->model('Partner_model');
        $data['list_partner'] = $this->Partner_model->find();

        if($this->form_validation->run()){


          //On applique les changements
          $additional_data = array(
            'ip_address' => $this->input->ip_address(),
            'last_name' => $data['last_name'],
            'created_on' => time(),
            'created_on_readable' => date('Y-m-d H:i:s'),
            'last_login' => time(),
            'active' => 1
          );

          //On enregistre les données de l'utilisateur pour la session
          $user_data = $data;

          $user_data['connected'] = TRUE;
          $this->session->set_userdata($user_data);

          // Alerte les administrateurs (Notifications & Email)
          $this->load->library('email');
          $this->load->model('Notification_model');

          $this->email->from($user_data['email'], $user_data['username']);
          $this->email->to(AEGIS_MAIL);
          

          $this->email->subject($data['sujet']);
          $this->email->message($data['msg']);

          $this->email->send();

          $admins = $this->Users_model->find(array('admin' => PGSQL_TRUE));
          foreach ($admins as $admin) {
            $this->Notification_model->create(array(
              'target_login' => $admin['username'],
              'notification_type' => NEW_USER,
              'sender_login' => $data['username'],
              'created_time' => 'NOW()',
              'ressource' => $data['username']
            ));
          }
          

          //Redirection
          //redirect("Welcome/index", "location");
          //return;
        }
        $scripts = array( 'selectize',
                          'verifie_pseudo',
                          'init_organization_select'
                        );
        
        
        $this->view('welcome/contact', 'Nous Contacter' . $data['username'], 'Vous pouvez nous contacter à partir de cette page.' . $data['username'], $scripts);

    }//end_envoi


}//end_class
